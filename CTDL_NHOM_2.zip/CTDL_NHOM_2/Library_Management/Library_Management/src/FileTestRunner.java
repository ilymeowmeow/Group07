import datastructure.BookBST;
import datastructure.ReaderBST;
import model.Sach;
import model.DocGia;
import java.io.*;
import java.time.LocalDate;
import java.util.List;

/**
 * Class để test chương trình với file input và output
 * Đọc dữ liệu từ input.txt, xử lý BST, ghi kết quả vào output.txt
 */
public class FileTestRunner {
    private BookBST bookBST;
    private ReaderBST readerBST;
    private PrintWriter output;

    public FileTestRunner() {
        bookBST = new BookBST();
        readerBST = new ReaderBST();
    }

    public void runTest(String inputFile, String outputFile) {
        try {
            output = new PrintWriter(new FileWriter(outputFile));
            
            printHeader("BẮT ĐẦU TEST CHƯƠNG TRÌNH QUẢN LÝ THƯ VIỆN");
            printHeader("SỬ DỤNG CẤU TRÚC DỮ LIỆU: BINARY SEARCH TREE (BST)");
            output.println();

            // Đọc và xử lý file input
            readAndProcessInput(inputFile);

            // Thực hiện các test operations
            performTests();

            printHeader("KẾT THÚC TEST");
            output.close();
            
            System.out.println("Test hoàn tất!");
            System.out.println("Kết quả đã được ghi vào: " + outputFile);
            
        } catch (IOException e) {
            System.err.println("Lỗi: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void readAndProcessInput(String inputFile) throws IOException {
        printHeader("1. ĐỌC DỮ LIỆU TỪ FILE INPUT");
        output.println("File: " + inputFile);
        output.println();

        BufferedReader br = new BufferedReader(new FileReader(inputFile));
        String line;
        String currentSection = "";
        int bookCount = 0;
        int readerCount = 0;

        while ((line = br.readLine()) != null) {
            line = line.trim();
            
            // Bỏ qua dòng trống và comment
            if (line.isEmpty() || line.startsWith("#")) {
                continue;
            }
            
            // Kiểm tra section header
            if (line.equals("[BOOKS]")) {
                currentSection = "BOOKS";
                output.println("--- Đọc danh sách SÁCH ---");
                continue;
            }
            if (line.equals("[READERS]")) {
                currentSection = "READERS";
                output.println();
                output.println("--- Đọc danh sách ĐỘC GIẢ ---");
                continue;
            }

            // Parse theo section hiện tại
            String[] parts = line.split(",");
            
            if (currentSection.equals("BOOKS") && parts.length >= 7) {
                try {
                    Sach sach = new Sach(
                        parts[0].trim(),  // maSach
                        parts[1].trim(),  // tenSach
                        parts[2].trim(),  // tacGia
                        parts[3].trim(),  // theLoai
                        Integer.parseInt(parts[4].trim()),  // namXuatBan
                        Integer.parseInt(parts[5].trim()),  // soLuong
                        parts[6].trim()   // moTa
                    );
                    bookBST.insert(sach);
                    bookCount++;
                    output.println(" Đã thêm sách: " + parts[0].trim() + " - " + parts[1].trim());
                } catch (NumberFormatException e) {
                    output.println(" Lỗi định dạng số tại dòng: " + line);
                }
                
            } else if (currentSection.equals("READERS") && parts.length >= 6) {
                try {
                    DocGia reader = new DocGia(
                        parts[5].trim(),  // maNguoiDung (mã độc giả)
                        parts[1].trim(),  // hoTen
                        parts[2].trim(),  // email
                        parts[3].trim(),  // soDienThoai
                        parts[4].trim(),  // matKhau
                        parts[0].trim(),  // maThe
                        LocalDate.now(),  // ngayDangKy
                        LocalDate.now().plusYears(1)  // ngayHetHan
                    );
                    readerBST.insert(reader);
                    readerCount++;
                    output.println(" Đã thêm độc giả: " + parts[0].trim() + " - " + parts[1].trim());
                } catch (Exception e) {
                    output.println(" Lỗi tại dòng: " + line);
                }
            }
        }
        br.close();

        output.println();
        output.println("Tổng số sách đã thêm vào BST: " + bookCount);
        output.println("Kích thước BookBST: " + bookBST.getSize());
        output.println("Tổng số độc giả đã thêm vào BST: " + readerCount);
        output.println("Kích thước ReaderBST: " + readerBST.getSize());
        output.println();
    }

    private void performTests() {
        // Test Books
        testInorderTraversal();
        testSearchById();
        testSearchByKeyword();
        testDelete();
        testFinalState();
        
        // Test Readers
        testReaderTraversal();
        testReaderSearch();
        testReaderDelete();
        testReaderFinalState();
    }

    private void testInorderTraversal() {
        printHeader("2. IN-ORDER TRAVERSAL (DANH SÁCH ĐÃ SẮP XẾP THEO TÊN)");
        
        List<Sach> books = bookBST.inorderTraversal();
        
        if (books.isEmpty()) {
            output.println("  (Danh sách rỗng)");
        } else {
            for (int i = 0; i < books.size(); i++) {
                Sach sach = books.get(i);
                output.printf("  %d. [%s] %s\n", 
                    i + 1, 
                    sach.getMaSach(), 
                    sach.getTenSach());
                output.printf("     Tác giả: %s | Thể loại: %s | Năm XB: %d | Số lượng: %d\n",
                    sach.getTacGia(),
                    sach.getTheLoai(),
                    sach.getNamXuatBan(),
                    sach.getSoLuong());
                output.printf("     Mô tả: %s\n", sach.getMoTa());
                output.println();
            }
        }
        
        output.println("Tổng số sách: " + books.size());
        output.println();
    }

    private void testSearchById() {
        printHeader("3. TEST TÌM KIẾM THEO MÃ SÁCH");
        
        String[] testIds = {"S001", "S003", "S999"};
        
        for (String maSach : testIds) {
            output.println("Tìm kiếm mã sách: " + maSach);
            Sach found = bookBST.searchByMaSach(maSach);
            
            if (found != null) {
                output.println(" Tìm thấy: " + found.getTenSach() + " (" + found.getTacGia() + ")");
            } else {
                output.println(" Không tìm thấy");
            }
            output.println();
        }
    }

    private void testSearchByKeyword() {
        printHeader("4. TEST TÌM KIẾM THEO TỪ KHÓA");
        
        String[] keywords = {"Java", "Công nghệ", "Carnegie"};
        
        for (String keyword : keywords) {
            output.println("Tìm kiếm từ khóa: \"" + keyword + "\"");
            List<Sach> results = bookBST.searchByKeyword(keyword);
            
            if (results.isEmpty()) {
                output.println(" Không tìm thấy kết quả");
            } else {
                output.println(" Tìm thấy " + results.size() + " kết quả:");
                for (Sach sach : results) {
                    output.println("    - " + sach.getMaSach() + ": " + sach.getTenSach());
                }
            }
            output.println();
        }
    }

    private void testDelete() {
        printHeader("5. TEST XÓA SÁCH");
        
        String maSachToDelete = "S001";
        output.println("Xóa sách có mã: " + maSachToDelete);
        
        Sach sach = bookBST.searchByMaSach(maSachToDelete);
        if (sach != null) {
            output.println("  Tìm thấy: " + sach.getTenSach());
            boolean deleted = bookBST.delete(sach.getTenSach());
            
            if (deleted) {
                output.println(" Xóa thành công");
                output.println(" Kích thước BST sau khi xóa: " + bookBST.getSize());
            } else {
                output.println(" Xóa thất bại");
            }
        } else {
            output.println(" Không tìm thấy sách để xóa");
        }
        output.println();
    }

    private void testFinalState() {
        printHeader("6. TRẠNG THÁI CUỐI CÙNG CỦA BST");
        
        List<Sach> finalBooks = bookBST.getAllBooks();
        
        output.println("Kích thước cuối cùng: " + bookBST.getSize());
        output.println("Danh sách sách còn lại:");
        output.println();
        
        for (int i = 0; i < finalBooks.size(); i++) {
            Sach sach = finalBooks.get(i);
            output.printf("  %d. %s - %s (%s)\n", 
                i + 1,
                sach.getMaSach(),
                sach.getTenSach(),
                sach.getTacGia());
        }
        output.println();
    }
    
    private void testReaderTraversal() {
        printHeader("7. IN-ORDER TRAVERSAL ĐỘC GIẢ (DANH SÁCH ĐÃ SẮP XẾP THEO TÊN)");
        
        List<DocGia> readers = readerBST.inorderTraversal();
        
        if (readers.isEmpty()) {
            output.println("  (Danh sách rỗng)");
        } else {
            for (int i = 0; i < readers.size(); i++) {
                DocGia reader = readers.get(i);
                output.printf("  %d. [%s] %s\n", 
                    i + 1,
                    reader.getMaThe(),
                    reader.getHoTen());
                output.printf("     Email: %s | SĐT: %s | Mã ĐG: %s\n",
                    reader.getEmail(),
                    reader.getSoDienThoai(),
                    reader.getMaNguoiDung());
                output.println();
            }
        }
        
        output.println("Tổng số độc giả: " + readers.size());
        output.println();
    }
    
    private void testReaderSearch() {
        printHeader("8. TEST TÌM KIẾM ĐỘC GIẢ");
        
        String[] testIds = {"DG001", "DG003", "DG999"};
        
        for (String maDocGia : testIds) {
            output.println("Tìm kiếm mã độc giả: " + maDocGia);
            DocGia found = readerBST.search(maDocGia);
            
            if (found != null) {
                output.println(" Tìm thấy: " + found.getHoTen() + " (" + found.getEmail() + ")");
            } else {
                output.println(" Không tìm thấy");
            }
            output.println();
        }
    }
    
    private void testReaderDelete() {
        printHeader("9. TEST XÓA ĐỘC GIẢ");
        
        String maDocGiaToDelete = "DG001";
        output.println("Xóa độc giả có mã: " + maDocGiaToDelete);
        
        DocGia reader = readerBST.search(maDocGiaToDelete);
        if (reader != null) {
            output.println("  Tìm thấy: " + reader.getHoTen());
            boolean deleted = readerBST.delete(maDocGiaToDelete);
            
            if (deleted) {
                output.println(" Xóa thành công");
                output.println(" Kích thước ReaderBST sau khi xóa: " + readerBST.getSize());
            } else {
                output.println(" Xóa thất bại");
            }
        } else {
            output.println(" Không tìm thấy độc giả để xóa");
        }
        output.println();
    }
    
    private void testReaderFinalState() {
        printHeader("10. TRẠNG THÁI CUỐI CÙNG CỦA READER BST");
        
        List<DocGia> finalReaders = readerBST.getAllReaders();
        
        output.println("Kích thước cuối cùng: " + readerBST.getSize());
        output.println("Danh sách độc giả còn lại:");
        output.println();
        
        for (int i = 0; i < finalReaders.size(); i++) {
            DocGia reader = finalReaders.get(i);
            output.printf("  %d. %s - %s (%s)\n", 
                i + 1,
                reader.getMaThe(),
                reader.getHoTen(),
                reader.getEmail());
        }
        output.println();
    }

    private void printHeader(String title) {
        output.println(title);
        output.println();
    }

    public static void main(String[] args) {
        System.out.println("========================================");
        System.out.println("   CHƯƠNG TRÌNH TEST FILE INPUT/OUTPUT");
        System.out.println("========================================");
        System.out.println();

        FileTestRunner runner = new FileTestRunner();
        runner.runTest("input.txt", "output.txt");
        
        System.out.println();
        System.out.println("💡 Hướng dẫn:");
        System.out.println("   - Xem file input.txt để biết dữ liệu đầu vào");
        System.out.println("   - Xem file output.txt để xem kết quả test");
    }
}
