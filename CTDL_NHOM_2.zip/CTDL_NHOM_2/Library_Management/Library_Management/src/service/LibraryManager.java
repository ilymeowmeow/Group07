package service;

import datastructure.BookBST;
import datastructure.ReaderBST;
import model.*;
import java.io.*;
import java.time.LocalDate;
import java.util.*;

/**
 * Lớp quản lý toàn bộ hệ thống thư viện
 */
public class LibraryManager {
    private static LibraryManager instance;
    
    private BookBST bookBST;
    private ReaderBST readerBST;
    private List<PhieuMuonSach> borrowRecords;
    private List<Admin> admins;
    private Admin currentAdmin;
    private DocGia currentReader;

    private LibraryManager() {
        bookBST = new BookBST();
        readerBST = new ReaderBST();
        borrowRecords = new ArrayList<>();
        admins = new ArrayList<>();
        
        // Đọc dữ liệu từ input.txt
        if (!loadDataFromFile("input.txt")) {
            // Nếu không có file, dùng dữ liệu mẫu
            initializeSampleData();
        }
    }

    public static LibraryManager getInstance() {
        if (instance == null) {
            instance = new LibraryManager();
        }
        return instance;
    }

    // Khởi tạo dữ liệu mẫu
    private void initializeSampleData() {
        // Thêm admin mặc định
        Admin admin = new Admin("admin", "Nguyễn Văn A", "admin@library.com",
                               "0123456789", "admin", "Quản trị viên");
        admin.themQuyenTruyCap("Quản lý sách");
        admin.themQuyenTruyCap("Quản lý độc giả");
        admin.themQuyenTruyCap("Quản lý mượn trả");
        admins.add(admin);

        // Thêm độc giả mẫu
        DocGia reader1 = new DocGia("DG001", "Trần Thị B", "reader1@email.com", 
                                   "0987654321", "123", "THE001",
                                   LocalDate.now(), LocalDate.now().plusYears(1));
        DocGia reader2 = new DocGia("DG002", "Lê Văn C", "reader2@email.com", 
                                   "0976543210", "123", "THE002",
                                   LocalDate.now(), LocalDate.now().plusYears(1));
        readerBST.insert(reader1);
        readerBST.insert(reader2);

        // Thêm sách mẫu
        bookBST.insert(new Sach("S001", "How do you live", "Miyazaki Hayao",
                               "Văn học", 2023, 10, "Tiểu thuyết kinh điển của Nhật Bản"));
        bookBST.insert(new Sach("S002", "Cấu trúc dữ liệu và giải thuật", "Trần Thị Anh",
                               "Công nghệ", 2022, 8, "Học về cấu trúc dữ liệu"));
        bookBST.insert(new Sach("S003", "Đắc nhân tâm", "Dale Carnegie", 
                               "Kỹ năng sống", 2020, 15, "Nghệ thuật giao tiếp và làm việc"));
        bookBST.insert(new Sach("S004", "Nhà giả kim", "Paulo Coelho", 
                               "Văn học", 2018, 12, "Truyện ngụ ngôn về hành trình tìm kiếm ước mơ"));
        bookBST.insert(new Sach("S005", "Thuật toán và ứng dụng", "Lê Văn Anh",
                               "Công nghệ", 2023, 6, "Các thuật toán phổ biến"));
    }

    // ========== QUẢN LÝ ĐĂNG NHẬP ==========
    public Admin loginAdmin(String username, String password) {
        for (Admin admin : admins) {
            if (admin.getMaNguoiDung().equals(username) && admin.getMatKhau().equals(password)) {
                currentAdmin = admin;
                return admin;
            }
        }
        return null;
    }

    public DocGia loginReader(String username, String password) {
        DocGia reader = readerBST.search(username);
        if (reader != null && reader.getMatKhau().equals(password)) {
            currentReader = reader;
            return reader;
        }
        return null;
    }

    public void logout() {
        currentAdmin = null;
        currentReader = null;
    }

    // ========== QUẢN LÝ SÁCH ==========
    public void addBook(Sach sach) {
        bookBST.insert(sach);
    }

    public boolean deleteBook(String maSach) {
        Sach sach = bookBST.searchByMaSach(maSach);
        if (sach != null) {
            return bookBST.delete(sach.getTenSach());
        }
        return false;
    }

    public List<Sach> getAllBooks() {
        return bookBST.getAllBooks();
    }

    public Sach searchBookById(String maSach) {
        return bookBST.searchByMaSach(maSach);
    }

    public List<Sach> searchBooksByKeyword(String keyword) {
        return bookBST.searchByKeyword(keyword);
    }
    
    // Alias methods for easier access
    public Sach getBookByID(String maSach) {
        return searchBookById(maSach);
    }

    // ========== QUẢN LÝ ĐỘC GIẢ ==========
    public void addReader(DocGia docGia) {
        readerBST.insert(docGia);
    }

    public boolean deleteReader(String maDocGia) {
        return readerBST.delete(maDocGia);
    }

    public List<DocGia> getAllReaders() {
        return readerBST.getAllReaders();
    }

    public DocGia searchReaderById(String maDocGia) {
        return readerBST.search(maDocGia);
    }

    public List<DocGia> searchReadersByName(String name) {
        return readerBST.searchByName(name);
    }
    
    // Alias methods for easier access
    public DocGia getReaderByID(String maDocGia) {
        return searchReaderById(maDocGia);
    }
    
    public DocGia getReaderByCardNumber(String maThe) {
        // Tìm độc giả theo mã thẻ
        List<DocGia> allReaders = readerBST.getAllReaders();
        for (DocGia reader : allReaders) {
            if (reader.getMaThe().equals(maThe)) {
                return reader;
            }
        }
        return null;
    }

    // ========== QUẢN LÝ MƯỢN TRẢ ==========
    public boolean borrowBook(String maDocGia, String maSach, int soNgayMuon) {
        DocGia reader = readerBST.search(maDocGia);
        Sach book = bookBST.searchByMaSach(maSach);

        if (reader == null || book == null || book.getSoLuong() <= 0) {
            return false;
        }

        // Kiểm tra thẻ hết hạn
        if (reader.getNgayHetHan().isBefore(LocalDate.now())) {
            return false;
        }

        // Tạo phiếu mượn
        String maPhieu = "PM" + System.currentTimeMillis();
        LocalDate ngayMuon = LocalDate.now();
        LocalDate ngayTraDuKien = ngayMuon.plusDays(soNgayMuon);
        
        PhieuMuonSach phieu = new PhieuMuonSach(maPhieu, maDocGia, maSach, ngayMuon, ngayTraDuKien);
        borrowRecords.add(phieu);

        // Giảm số lượng sách
        book.setSoLuong(book.getSoLuong() - 1);

        // Thêm vào lịch sử mượn
        reader.themLichSuMuon("Mượn: " + book.getTenSach() + " - " + ngayMuon);

        return true;
    }

    public boolean returnBook(String maPhieu) {
        for (PhieuMuonSach phieu : borrowRecords) {
            if (phieu.getMaPhieu().equals(maPhieu) && phieu.getTinhTrang().equals("Đang mượn")) {
                // Cập nhật phiếu
                phieu.setNgayTraThucTe(LocalDate.now());
                phieu.setTinhTrang("Đã trả");

                // Tăng số lượng sách
                Sach book = bookBST.searchByMaSach(phieu.getMaSach());
                if (book != null) {
                    book.setSoLuong(book.getSoLuong() + 1);
                }

                // Cập nhật lịch sử
                DocGia reader = readerBST.search(phieu.getMaDocGia());
                if (reader != null) {
                    reader.themLichSuMuon("Trả: " + book.getTenSach() + " - " + LocalDate.now());
                }

                return true;
            }
        }
        return false;
    }

    public List<PhieuMuonSach> getAllBorrowRecords() {
        return new ArrayList<>(borrowRecords);
    }

    public List<PhieuMuonSach> getBorrowRecordsByReader(String maDocGia) {
        List<PhieuMuonSach> result = new ArrayList<>();
        for (PhieuMuonSach phieu : borrowRecords) {
            if (phieu.getMaDocGia().equals(maDocGia)) {
                result.add(phieu);
            }
        }
        return result;
    }

    public List<PhieuMuonSach> getActiveBorrowRecords() {
        List<PhieuMuonSach> result = new ArrayList<>();
        for (PhieuMuonSach phieu : borrowRecords) {
            if (phieu.getTinhTrang().equals("Đang mượn")) {
                result.add(phieu);
            }
        }
        return result;
    }

    // ========== THỐNG KÊ ==========
    public int getTotalBooks() {
        return bookBST.getSize();
    }

    public int getTotalReaders() {
        return readerBST.getSize();
    }

    public int getTotalBorrowRecords() {
        return borrowRecords.size();
    }

    public int getActiveBorrowCount() {
        int count = 0;
        for (PhieuMuonSach phieu : borrowRecords) {
            if (phieu.getTinhTrang().equals("Đang mượn")) {
                count++;
            }
        }
        return count;
    }

    public int getOverdueBorrowCount() {
        int count = 0;
        for (PhieuMuonSach phieu : borrowRecords) {
            if (phieu.isQuaHan()) {
                count++;
            }
        }
        return count;
    }

    // Getters
    public Admin getCurrentAdmin() {
        return currentAdmin;
    }

    public DocGia getCurrentReader() {
        return currentReader;
    }
    
    // ========== ĐỌC DỮ LIỆU TỪ FILE ==========
    /**
     * Đọc dữ liệu từ file input
     * Format: MaSach,TenSach,TacGia,TheLoai,NamXuatBan,SoLuong,MoTa
     * @param filename Tên file input
     * @return true nếu đọc thành công, false nếu file không tồn tại
     */
    private boolean loadDataFromFile(String filename) {
        File file = new File(filename);
        
        if (!file.exists()) {
            System.out.println("File " + filename + " không tồn tại. Sử dụng dữ liệu mẫu.");
            return false;
        }
        
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            String currentSection = "";
            int bookCount = 0;
            int readerCount = 0;
            
            System.out.println("Đang đọc dữ liệu từ file: " + filename);
            
            // Khởi tạo admin mặc định
            Admin admin = new Admin("admin", "Quản trị viên", "admin@library.com",
                                   "0123456789", "admin", "Quản trị viên");
            admin.themQuyenTruyCap("Quản lý sách");
            admin.themQuyenTruyCap("Quản lý độc giả");
            admin.themQuyenTruyCap("Quản lý mượn trả");
            admins.add(admin);
            
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                
                // Bỏ qua dòng trống và comment
                if (line.isEmpty() || line.startsWith("#")) {
                    continue;
                }
                
                // Kiểm tra section header
                if (line.equals("[BOOKS]")) {
                    currentSection = "BOOKS";
                    continue;
                }
                if (line.equals("[READERS]")) {
                    currentSection = "READERS";
                    continue;
                }
                
                // Parse theo section hiện tại
                String[] parts = line.split(",");
                
                if (currentSection.equals("BOOKS") && parts.length >= 7) {
                    try {
                        Sach sach = new Sach(
                            parts[0].trim(),  // maSach
                            parts[1].trim(),  // tenSach
                            parts[2].trim(),  // tacGia
                            parts[3].trim(),  // theLoai
                            Integer.parseInt(parts[4].trim()),  // namXuatBan
                            Integer.parseInt(parts[5].trim()),  // soLuong
                            parts[6].trim()   // moTa
                        );
                        bookBST.insert(sach);
                        bookCount++;
                    } catch (NumberFormatException e) {
                        System.err.println("Lỗi định dạng số tại dòng: " + line);
                    }
                    
                } else if (currentSection.equals("READERS") && parts.length >= 6) {
                    try {
                        DocGia docGia = new DocGia(
                            parts[5].trim(),  // maNguoiDung (mã độc giả)
                            parts[1].trim(),  // hoTen
                            parts[2].trim(),  // email
                            parts[3].trim(),  // soDienThoai
                            parts[4].trim(),  // matKhau
                            parts[0].trim(),  // maThe
                            LocalDate.now(),  // ngayDangKy
                            LocalDate.now().plusYears(1)  // ngayHetHan
                        );
                        readerBST.insert(docGia);
                        readerCount++;
                    } catch (Exception e) {
                        System.err.println("Lỗi tại dòng: " + line);
                    }
                }
            }
            
            System.out.println("Đã load " + bookCount + " sách và " + readerCount + " độc giả từ file " + filename);
            
            return true;
            
        } catch (IOException e) {
            System.err.println("Lỗi khi đọc file: " + e.getMessage());
            return false;
        }
    }
    
    //LƯU DỮ LIỆU RA FILE
    /**
     * Lưu dữ liệu sách hiện tại ra file
     * @param filename Tên file để lưu
     * @return true nếu lưu thành công
     */
    public boolean saveDataToFile(String filename) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(filename))) {
            writer.println("# FILE DỮ LIỆU - Tự động tạo bởi chương trình");
            writer.println();
            
            // Lưu sách
            writer.println("[BOOKS]");
            writer.println("# Format: MaSach,TenSach,TacGia,TheLoai,NamXuatBan,SoLuong,MoTa");
            
            List<Sach> books = bookBST.getAllBooks();
            for (Sach sach : books) {
                writer.printf("%s,%s,%s,%s,%d,%d,%s%n",
                    sach.getMaSach(),
                    sach.getTenSach(),
                    sach.getTacGia(),
                    sach.getTheLoai(),
                    sach.getNamXuatBan(),
                    sach.getSoLuong(),
                    sach.getMoTa());
            }
            
            writer.println();
            
            // Lưu độc giả
            writer.println("[READERS]");
            writer.println("# Format: MaThe,HoTen,Email,SoDienThoai,MatKhau,MaDocGia");
            
            List<DocGia> readers = readerBST.getAllReaders();
            for (DocGia reader : readers) {
                writer.printf("%s,%s,%s,%s,%s,%s%n",
                    reader.getMaThe(),
                    reader.getHoTen(),
                    reader.getEmail(),
                    reader.getSoDienThoai(),
                    reader.getMatKhau(),
                    reader.getMaNguoiDung());
            }
            
            System.out.println("Đã lưu " + books.size() + " sách và " + readers.size() + " độc giả vào file " + filename);
            return true;
            
        } catch (IOException e) {
            System.err.println("Lỗi khi lưu file: " + e.getMessage());
            return false;
        }
    }
}
