# Project IMS

```bash

├─ README.md
├─ .env                                 # DATABASE_URI="mssql+pymssql://sa:Aa123456@127.0.0.1:1433/IMS"
├─ .venv/
├─ requirements.txt
└─ src/
   ├─ __init__.py
   ├─ api/
   │  ├─ __init__.py
   │  ├─ controllers/
   │  │  ├─ user_controller.py
   │  │  ├─ intern_controller.py
   │  │  ├─ recruitment_controller.py
   │  │  ├─ application_controller.py
   │  │  ├─ training_controller.py
   │  │  ├─ project_controller.py
   │  │  ├─ assignment_controller.py
   │  │  └─ evaluation_controller.py
   │  ├─ schemas/
   │  │  ├─ user_schema.py
   │  │  ├─ intern_schema.py
   │  │  ├─ recruitment_schema.py
   │  │  ├─ application_schema.py
   │  │  ├─ training_schema.py
   │  │  ├─ project_schema.py
   │  │  ├─ assignment_schema.py
   │  │  └─ evaluation_schema.py
   │  ├─ middleware.py                  # JWT/RBAC (tùy chọn), logging, request-id
   │  ├─ responses.py                   # chuẩn hóa JSON response
   │  └─ requests.py                    
   │
   ├─ domain/
   │  ├─ __init__.py
   │  ├─ constants.py
   │  ├─ exceptions.py                  # DomainError/ValidationError/NotFoundError...
   │  └─ models/
   │     ├─ user.py
   │     ├─ intern.py
   │     ├─ recruitment.py
   │     ├─ application.py
   │     ├─ training.py
   │     ├─ project.py
   │     ├─ assignment.py
   │     └─ evaluation.py
   │
   ├─ services/
   │  ├─ __init__.py
   │  ├─ identity_service.py            # User, InternProfile
   │  ├─ recruitment_service.py         # RecruitmentCampaign, Application
   │  ├─ training_service.py            # TrainingProgram, Project
   │  ├─ work_service.py                # Assignment
   │  └─ evaluation_service.py          # Evaluation
   │
   ├─ infrastructure/
   │  ├─ __init__.py
   │  ├─ databases/
   │  │  ├─ __init__.py                 # re-export engine, Base, SessionLocal, init_engine/get_session
   │  │  └─ db_base.py                  # tạo Engine/Session (dùng DATABASE_URI từ env), Base = declarative_base()
   │  ├─ models/                        # ORM mapping — áp dụng [Đề xuất #4, #5]
   │  │  ├─ __init__.py
   │  │  ├─ identity_models.py          # User, InternProfile (role CHECK, email UNIQUE, 1–1)
   │  │  ├─ recruitment_models.py       # RecruitmentCampaign (Open/Closed), Application (UNIQUE campID+userID)
   │  │  ├─ training_models.py          # TrainingProgram, Project (FK RESTRICT)
   │  │  ├─ work_models.py              # Assignment (status CHECK; no cascade delete)
   │  │  └─ evaluation_models.py        # Evaluation (score CHECK 0..100)
   │  ├─ repositories/
   │  │  ├─ __init__.py
   │  │  ├─ identity_repository.py
   │  │  ├─ recruitment_repository.py
   │  │  ├─ training_repository.py
   │  │  ├─ work_repository.py
   │  │  └─ evaluation_repository.py
   │  └─ services/
   │     ├─ __init__.py
   │     └─ email_service.py            # (tùy chọn)
   │
   ├─ tests/                            # pytest: unit + integration theo 5 nhóm 
   │  ├─ __init__.py
   │  ├─ conftest.py                    # app/test_client/DB session fixture (transational)
   │  ├─ test_identity.py               # User/InternProfile
   │  ├─ test_recruitment.py            # Campaign/Application
   │  ├─ test_training.py               # Program/Project
   │  ├─ test_assignment.py             # Assignment state machine
   │  └─ test_evaluation.py             # CRUD + avgScore
   ├─ app.py                            # ENTRY: from create_app import create_app; app = create_app()
   ├─ wsgi.py                           # cho deploy WSGI server (gunicorn/uwsgi)
   ├─ create_app.py                     # app factory: init DB/session, đăng ký blueprint, errors
   ├─ config.py
   ├─ app_logging.py
   ├─ cors.py
   ├─ error_handler.py                  # chuẩn hóa lỗi + HTTPException mapping
   ├─ enums.py                          # chỉ Enum Python; DB dùng VARCHAR + CHECK
   ├─ dependency_container.py           # khởi tạo repo/service; inject vào controllers
   ├─ db_create_all.py
   ├─ db_reset.py
