from __future__ import annotations

from flask import Blueprint, g
from sqlalchemy import and_
from ..responses import ok, created, paginated, no_content
from ..requests import get_json, qint, qstr, pagination as pg
from ...error_handler import NotFoundError, ConflictError, ValidationError
from ...infrastructure.models.recruitment_models import Application, RecruitmentCampaign
from ...infrastructure.models.identity_models import User
from ...enums import ApplicationStatus, CampaignStatus
from ..middleware import roles_required

# Schemas
from ..schemas.application_schema import ApplicationCreateSchema, ApplicationOutSchema

bp = Blueprint("applications", __name__)


@bp.post("/applications")
@roles_required("Intern", "HR", "Admin")
def create_application():
    """
    Create a new application
    ---
    tags: [Applications]
    summary: Create a new application
    description: Create an application for a user to a recruitment campaign.
    parameters:
      - in: body
        name: body
        required: true
        schema:
          type: object
          required: [campID, userID]
          properties:
            campID:
              type: integer
              example: 1
            userID:
              type: integer
              example: 3
    responses:
      201:
        description: Created
        schema:
          $ref: "#/definitions/OkWrapper"
        headers:
          Location:
            type: string
            description: Resource URL of the created application
      400:
        description: Bad request
        schema:
          $ref: "#/definitions/Error"
      401:
        description: Unauthorized / Forbidden (role)
        schema:
          $ref: "#/definitions/Error"
      404:
        description: Campaign or User not found
        schema:
          $ref: "#/definitions/Error"
      409:
        description: Duplicate application or campaign not open
        schema:
          $ref: "#/definitions/Error"
    """
    payload = ApplicationCreateSchema().load(get_json(required=True))
    camp_id = int(payload["campID"])
    user_id = int(payload["userID"])

    # Check campaign
    camp = g.db.get(RecruitmentCampaign, camp_id)
    if not camp:
        raise ValidationError("Campaign not found")
    if camp.status != CampaignStatus.Open.value:
        raise ConflictError("Campaign is not Open")

    # Check user
    if not g.db.get(User, user_id):
        raise ValidationError("User not found")

    # Unique (campID, userID)
    exists = g.db.query(Application).filter(
        and_(Application.campID == camp_id, Application.userID == user_id)
    ).first()
    if exists:
        raise ConflictError("Application already exists for (campID,userID)")

    app = Application(campID=camp_id, userID=user_id, status=ApplicationStatus.Pending.value)
    g.db.add(app)
    g.db.flush()
    return created(ApplicationOutSchema().dump(app), location=f"/api/applications/{app.appID}")


@bp.get("/applications/<int:app_id>")
@roles_required("Admin", "HR")
def get_application(app_id: int):
    """
    Get an application by ID
    ---
    tags: [Applications]
    summary: Get an application by ID
    parameters:
      - in: path
        name: app_id
        type: integer
        required: true
        description: Application ID
    responses:
      200:
        description: OK
        schema:
          $ref: "#/definitions/OkWrapper"
      401:
        description: Unauthorized / Forbidden (role)
        schema:
          $ref: "#/definitions/Error"
      404:
        description: Not Found
        schema:
          $ref: "#/definitions/Error"
    """
    app = g.db.get(Application, app_id)
    if not app:
        raise NotFoundError("Application not found")
    return ok(ApplicationOutSchema().dump(app))


@bp.get("/applications")
@roles_required("Admin", "HR")
def list_applications():
    """
    List applications
    ---
    tags: [Applications]
    summary: List applications
    parameters:
      - in: query
        name: campID
        type: integer
        required: false
        description: Filter by campaign ID
      - in: query
        name: status
        type: string
        enum: [Pending, Approved, Rejected]
        required: false
        description: Filter by application status
      - in: query
        name: limit
        type: integer
        default: 50
        description: Page size
      - in: query
        name: offset
        type: integer
        default: 0
        description: Offset for pagination
    responses:
      200:
        description: OK
        schema:
          type: object
          properties:
            success:
              type: boolean
              example: true
            data:
              type: array
              items:
                type: object
                properties:
                  appID:  { type: integer, example: 10 }
                  campID: { type: integer, example: 1 }
                  userID: { type: integer, example: 3 }
                  status:
                    type: string
                    enum: [Pending, Approved, Rejected]
                    example: "Pending"
            meta:
              $ref: "#/definitions/Pagination"
      401:
        description: Unauthorized / Forbidden (role)
        schema:
          $ref: "#/definitions/Error"
    """
    limit, offset = pg()
    camp_id = qint("campID")
    status = qstr("status")
    q = g.db.query(Application)
    if camp_id is not None:
        q = q.filter(Application.campID == camp_id)
    if status:
        q = q.filter(Application.status == status)
    total = q.count()
    items = (
        q.order_by(Application.appID.asc())
         .offset(offset).limit(limit).all()
    )
    return paginated(ApplicationOutSchema(many=True).dump(items), total=total, limit=limit, offset=offset)


@bp.delete("/applications/<int:app_id>")
@roles_required("Admin", "HR")
def delete_application(app_id: int):
    """
    Delete an application (Pending only)
    ---
    tags: [Applications]
    summary: Delete an application (Pending only)
    parameters:
      - in: path
        name: app_id
        type: integer
        required: true
        description: Application ID
    responses:
      204:
        description: No Content
      401:
        description: Unauthorized / Forbidden (role)
        schema:
          $ref: "#/definitions/Error"
      404:
        description: Not Found
        schema:
          $ref: "#/definitions/Error"
      409:
        description: Only Pending application can be deleted
        schema:
          $ref: "#/definitions/Error"
    """
    app = g.db.get(Application, app_id)
    if not app:
        raise NotFoundError("Application not found")
    if app.status != ApplicationStatus.Pending.value:
        raise ConflictError("Only Pending application can be deleted")
    g.db.delete(app)
    return no_content()


@bp.post("/applications/<int:app_id>/approve")
@roles_required("Admin", "HR")
def approve_application(app_id: int):
    """
    Approve an application (from Pending)
    ---
    tags: [Applications]
    summary: Approve an application (from Pending)
    parameters:
      - in: path
        name: app_id
        type: integer
        required: true
        description: Application ID
    responses:
      200:
        description: OK
        schema:
          $ref: "#/definitions/OkWrapper"
      401:
        description: Unauthorized / Forbidden (role)
        schema:
          $ref: "#/definitions/Error"
      404:
        description: Not Found
        schema:
          $ref: "#/definitions/Error"
      409:
        description: Only Pending application can be approved
        schema:
          $ref: "#/definitions/Error"
    """
    app = g.db.get(Application, app_id)
    if not app:
        raise NotFoundError("Application not found")
    if app.status != ApplicationStatus.Pending.value:
        raise ConflictError("Only Pending application can be approved")
    app.status = ApplicationStatus.Approved.value
    return ok(ApplicationOutSchema().dump(app))


@bp.post("/applications/<int:app_id>/reject")
@roles_required("Admin", "HR")
def reject_application(app_id: int):
    """
    Reject an application (from Pending)
    ---
    tags: [Applications]
    summary: Reject an application (from Pending)
    parameters:
      - in: path
        name: app_id
        type: integer
        required: true
        description: Application ID
    responses:
      200:
        description: OK
        schema:
          $ref: "#/definitions/OkWrapper"
      401:
        description: Unauthorized / Forbidden (role)
        schema:
          $ref: "#/definitions/Error"
      404:
        description: Not Found
        schema:
          $ref: "#/definitions/Error"
      409:
        description: Only Pending application can be rejected
        schema:
          $ref: "#/definitions/Error"
    """
    app = g.db.get(Application, app_id)
    if not app:
        raise NotFoundError("Application not found")
    if app.status != ApplicationStatus.Pending.value:
        raise ConflictError("Only Pending application can be rejected")
    app.status = ApplicationStatus.Rejected.value
    return ok(ApplicationOutSchema().dump(app))
