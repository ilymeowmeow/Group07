from __future__ import annotations

from flask import Blueprint, g
from ..responses import ok, created, paginated, no_content
from ..requests import get_json, qint, pagination as pg
from ...error_handler import NotFoundError, ConflictError
from ...infrastructure.models.work_models import Assignment
from ...infrastructure.models.training_models import Project
from ...infrastructure.models.identity_models import InternProfile
from ...enums import AssignmentStatus
from ..middleware import roles_required

# Schemas
from ..schemas.assignment_schema import (
    AssignmentCreateSchema,
    AssignmentStatusUpdateSchema,
    AssignmentOutSchema,
)

bp = Blueprint("assignments", __name__)

ALLOWED = {
    AssignmentStatus.Pending.value: {AssignmentStatus.Doing.value},
    AssignmentStatus.Doing.value: {AssignmentStatus.Done.value},
    AssignmentStatus.Done.value: set(),
}


@bp.post("/assignments")
@roles_required("Coordinator", "Mentor")
def create_assignment():
    """
    Create an assignment for an intern
    ---
    tags:
      - Assignments
    summary: Create an assignment for an intern
    description: Giao nhiệm vụ cho intern trong một project. Trạng thái mặc định là **Pending**.
    parameters:
      - in: body
        name: body
        required: true
        schema:
          type: object
          properties:
            projID:
              type: integer
              example: 10
            internID:
              type: integer
              example: 5
            status:
              type: string
              enum: [Pending, Doing, Done]
              example: Pending
          required: [projID, internID]
    responses:
      201:
        description: Created
        headers:
          Location:
            type: string
            description: Resource URL of the created assignment
        schema:
          $ref: "#/definitions/OkWrapper"
      400:
        description: Bad request
        schema:
          $ref: "#/definitions/Error"
      401:
        description: Unauthorized / Forbidden (role)
        schema:
          $ref: "#/definitions/Error"
      409:
        description: Conflict (FK invalid hoặc ràng buộc khác)
        schema:
          $ref: "#/definitions/Error"
    """
    payload = AssignmentCreateSchema().load(get_json(required=True))
    # FK check (phòng trường hợp schema chưa check)
    if not g.db.get(Project, int(payload["projID"])):
        raise ConflictError("Invalid projID")
    if not g.db.get(InternProfile, int(payload["internID"])):
        raise ConflictError("Invalid internID")
    a = Assignment(**payload)
    g.db.add(a)
    g.db.flush()
    return created(AssignmentOutSchema().dump(a), location=f"/api/assignments/{a.assignID}")


@bp.get("/assignments/<int:assign_id>")
@roles_required("Admin", "HR", "Coordinator", "Mentor", "Intern")
def get_assignment(assign_id: int):
    """
    Get an assignment by ID
    ---
    tags:
      - Assignments
    summary: Get an assignment by ID
    parameters:
      - in: path
        name: assign_id
        type: integer
        required: true
        description: Assignment ID
    responses:
      200:
        description: OK
        schema:
          $ref: "#/definitions/OkWrapper"
      401:
        description: Unauthorized / Forbidden (role)
        schema:
          $ref: "#/definitions/Error"
      404:
        description: Not Found
        schema:
          $ref: "#/definitions/Error"
    """
    a = g.db.get(Assignment, assign_id)
    if not a:
        raise NotFoundError("Assignment not found")
    return ok(AssignmentOutSchema().dump(a))


@bp.get("/assignments")
@roles_required("Admin", "HR", "Coordinator", "Mentor", "Intern")
def list_assignments():
    """
    List assignments
    ---
    tags:
      - Assignments
    summary: List assignments
    description: Liệt kê assignment; hỗ trợ lọc theo `projID`, `internID` và phân trang.
    parameters:
      - in: query
        name: projID
        type: integer
        required: false
        description: Lọc theo project
      - in: query
        name: internID
        type: integer
        required: false
        description: Lọc theo intern
      - in: query
        name: limit
        type: integer
        required: false
        default: 50
        description: Page size
      - in: query
        name: offset
        type: integer
        required: false
        default: 0
        description: Offset
    responses:
      200:
        description: OK
        schema:
          type: object
          properties:
            success:
              type: boolean
              example: true
            data:
              type: array
              items:
                type: object
                properties:
                  assignID: { type: integer, example: 1001 }
                  projID:   { type: integer, example: 10 }
                  internID: { type: integer, example: 5 }
                  status:   { type: string,  example: "Pending" }
            meta:
              $ref: "#/definitions/Pagination"
      401:
        description: Unauthorized / Forbidden (role)
        schema:
          $ref: "#/definitions/Error"
    """
    limit, offset = pg()
    proj_id = qint("projID")
    intern_id = qint("internID")
    q = g.db.query(Assignment)
    if proj_id is not None:
        q = q.filter(Assignment.projID == proj_id)
    if intern_id is not None:
        q = q.filter(Assignment.internID == intern_id)
    total = q.count()
    items = (
        q.order_by(Assignment.assignID.asc())
         .offset(offset).limit(limit).all()
    )
    return paginated(AssignmentOutSchema(many=True).dump(items), total=total, limit=limit, offset=offset)


@bp.delete("/assignments/<int:assign_id>")
@roles_required("Coordinator", "Mentor", "Admin", "HR")
def delete_assignment(assign_id: int):
    """
    Delete an assignment
    ---
    tags:
      - Assignments
    summary: Delete an assignment
    description: Chỉ xóa khi trạng thái **khác Done**.
    parameters:
      - in: path
        name: assign_id
        type: integer
        required: true
        description: Assignment ID
    responses:
      204:
        description: No Content
      401:
        description: Unauthorized / Forbidden (role)
        schema:
          $ref: "#/definitions/Error"
      404:
        description: Not Found
        schema:
          $ref: "#/definitions/Error"
      409:
        description: Conflict (status = Done)
        schema:
          $ref: "#/definitions/Error"
    """
    a = g.db.get(Assignment, assign_id)
    if not a:
        raise NotFoundError("Assignment not found")
    if a.status == AssignmentStatus.Done.value:
        raise ConflictError("Cannot delete Assignment with status=Done")
    g.db.delete(a)
    return no_content()


@bp.post("/assignments/<int:assign_id>/status")
@roles_required("Intern", "Coordinator", "Mentor")
def update_assignment_status(assign_id: int):
    """
    Update assignment status
    ---
    tags:
      - Assignments
    summary: Update assignment status
    description: Cập nhật trạng thái theo state machine **Pending → Doing → Done** (không cho phép lùi).
    parameters:
      - in: path
        name: assign_id
        type: integer
        required: true
        description: Assignment ID
      - in: body
        name: body
        required: true
        schema:
          type: object
          properties:
            newStatus:
              type: string
              enum: [Pending, Doing, Done]
              example: Doing
          required: [newStatus]
    responses:
      200:
        description: OK
        schema:
          $ref: "#/definitions/OkWrapper"
      401:
        description: Unauthorized / Forbidden (role)
        schema:
          $ref: "#/definitions/Error"
      404:
        description: Not Found
        schema:
          $ref: "#/definitions/Error"
      409:
        description: Invalid transition
        schema:
          $ref: "#/definitions/Error"
    """
    a = g.db.get(Assignment, assign_id)
    if not a:
        raise NotFoundError("Assignment not found")
    data = AssignmentStatusUpdateSchema().load(get_json(required=True), context={"current_status": a.status})
    new_status = data["newStatus"]
    if new_status not in ALLOWED.get(a.status, set()):
        raise ConflictError(f"Invalid transition: {a.status} -> {new_status}")
    a.status = new_status
    return ok(AssignmentOutSchema().dump(a))
