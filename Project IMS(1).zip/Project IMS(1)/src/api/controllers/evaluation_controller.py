from __future__ import annotations

from flask import Blueprint, g
from sqlalchemy import func
from ..responses import ok, created, paginated, no_content
from ..requests import get_json, qint, pagination as pg
from ...error_handler import NotFoundError
from ...infrastructure.models.evaluation_models import Evaluation
from ..middleware import roles_required

# Schemas
from ..schemas.evaluation_schema import (
    EvaluationCreateSchema,
    EvaluationUpdateSchema,
    EvaluationOutSchema,
    AvgScoreOutSchema,
)

bp = Blueprint("evaluations", __name__)


@bp.post("/evaluations")
@roles_required("Coordinator", "Mentor", "Admin", "HR")
def create_evaluation():
    """
    Create an evaluation
    ---
    tags:
      - Evaluations
    summary: Create an evaluation
    description: Tạo điểm/đánh giá cho intern (score trong khoảng 0..100).
    parameters:
      - in: body
        name: body
        required: true
        schema:
          type: object
          properties:
            internID:
              type: integer
              example: 5
            score:
              type: number
              format: float
              minimum: 0
              maximum: 100
              example: 87
          required: [internID, score]
    responses:
      201:
        description: Created
        headers:
          Location:
            type: string
            description: Resource URL of the created evaluation
        schema:
          $ref: "#/definitions/OkWrapper"
      400:
        description: Bad request
        schema:
          $ref: "#/definitions/Error"
      401:
        description: Unauthorized / Forbidden (role)
        schema:
          $ref: "#/definitions/Error"
    """
    payload = EvaluationCreateSchema().load(get_json(required=True))
    e = Evaluation(**payload)
    g.db.add(e)
    g.db.flush()
    return created(EvaluationOutSchema().dump(e), location=f"/api/evaluations/{e.evalID}")


@bp.get("/evaluations/<int:eval_id>")
@roles_required("Admin", "HR", "Coordinator", "Mentor", "Intern")
def get_evaluation(eval_id: int):
    """
    Get an evaluation by ID
    ---
    tags:
      - Evaluations
    summary: Get an evaluation by ID
    parameters:
      - in: path
        name: eval_id
        type: integer
        required: true
        description: Evaluation ID
    responses:
      200:
        description: OK
        schema:
          $ref: "#/definitions/OkWrapper"
      401:
        description: Unauthorized / Forbidden (role)
        schema:
          $ref: "#/definitions/Error"
      404:
        description: Not Found
        schema:
          $ref: "#/definitions/Error"
    """
    e = g.db.get(Evaluation, eval_id)
    if not e:
        raise NotFoundError("Evaluation not found")
    return ok(EvaluationOutSchema().dump(e))


@bp.put("/evaluations/<int:eval_id>")
@roles_required("Coordinator", "Mentor", "Admin", "HR")
def update_evaluation(eval_id: int):
    """
    Update an evaluation
    ---
    tags:
      - Evaluations
    summary: Update an evaluation
    parameters:
      - in: path
        name: eval_id
        type: integer
        required: true
        description: Evaluation ID
      - in: body
        name: body
        required: true
        schema:
          type: object
          properties:
            score:
              type: number
              format: float
              minimum: 0
              maximum: 100
              example: 92
    responses:
      200:
        description: OK
        schema:
          $ref: "#/definitions/OkWrapper"
      401:
        description: Unauthorized / Forbidden (role)
        schema:
          $ref: "#/definitions/Error"
      404:
        description: Not Found
        schema:
          $ref: "#/definitions/Error"
    """
    e = g.db.get(Evaluation, eval_id)
    if not e:
        raise NotFoundError("Evaluation not found")
    data = EvaluationUpdateSchema().load(get_json(required=True))
    for k, v in data.items():
        setattr(e, k, v)
    return ok(EvaluationOutSchema().dump(e))


@bp.delete("/evaluations/<int:eval_id>")
@roles_required("Coordinator", "Mentor", "Admin", "HR")
def delete_evaluation(eval_id: int):
    """
    Delete an evaluation
    ---
    tags:
      - Evaluations
    summary: Delete an evaluation
    parameters:
      - in: path
        name: eval_id
        type: integer
        required: true
        description: Evaluation ID
    responses:
      204:
        description: No Content
      401:
        description: Unauthorized / Forbidden (role)
        schema:
          $ref: "#/definitions/Error"
      404:
        description: Not Found
        schema:
          $ref: "#/definitions/Error"
    """
    e = g.db.get(Evaluation, eval_id)
    if not e:
        raise NotFoundError("Evaluation not found")
    g.db.delete(e)
    return no_content()


@bp.get("/evaluations")
@roles_required("Admin", "HR", "Coordinator", "Mentor", "Intern")
def list_evaluations():
    """
    List evaluations
    ---
    tags:
      - Evaluations
    summary: List evaluations
    description: Liệt kê các evaluation; hỗ trợ lọc theo `internID` và phân trang.
    parameters:
      - in: query
        name: internID
        type: integer
        required: false
        description: Filter theo internID
      - in: query
        name: limit
        type: integer
        required: false
        default: 50
        description: Page size
      - in: query
        name: offset
        type: integer
        required: false
        default: 0
        description: Offset
    responses:
      200:
        description: OK
        schema:
          type: object
          properties:
            success:
              type: boolean
              example: true
            data:
              type: array
              items:
                type: object
                properties:
                  evalID:   { type: integer, example: 101 }
                  internID: { type: integer, example: 5 }
                  score:    { type: number, format: float, example: 87 }
            meta:
              $ref: "#/definitions/Pagination"
      401:
        description: Unauthorized / Forbidden (role)
        schema:
          $ref: "#/definitions/Error"
    """
    limit, offset = pg()
    intern_id = qint("internID")
    q = g.db.query(Evaluation)
    if intern_id is not None:
        q = q.filter(Evaluation.internID == intern_id)
    total = q.count()
    items = (
        q.order_by(Evaluation.evalID.asc())
         .offset(offset).limit(limit).all()
    )
    return paginated(EvaluationOutSchema(many=True).dump(items), total=total, limit=limit, offset=offset)


@bp.get("/evaluations/avg")
@roles_required("Admin", "HR", "Coordinator", "Mentor", "Intern")
def avg_score():
    """
    Average score of an intern
    ---
    tags:
      - Evaluations
    summary: Average score of an intern
    description: Trả về điểm trung bình của một intern. Nếu thiếu `internID`, trả message gợi ý.
    parameters:
      - in: query
        name: internID
        type: integer
        required: true
        description: InternProfile ID để tính trung bình
    responses:
      200:
        description: OK
        schema:
          $ref: "#/definitions/OkWrapper"
      401:
        description: Unauthorized / Forbidden (role)
        schema:
          $ref: "#/definitions/Error"
    """
    intern_id = qint("internID")
    if intern_id is None:
        # Giữ hành vi cũ: trả 200 + message, không raise 422.
        return ok({"message": "internID query param is required"})
    avg = g.db.query(func.avg(Evaluation.score)).filter(Evaluation.internID == intern_id).scalar()
    return ok(AvgScoreOutSchema().dump({"internID": intern_id, "avgScore": float(avg) if avg is not None else None}))
