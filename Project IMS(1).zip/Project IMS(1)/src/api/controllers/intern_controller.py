from __future__ import annotations

from flask import Blueprint, g
from ..responses import ok, created, paginated, no_content
from ..requests import get_json, qint, pagination as pg
from ...error_handler import NotFoundError, ConflictError
from ...infrastructure.models.identity_models import InternProfile
from ...infrastructure.models.work_models import Assignment
from ...infrastructure.models.evaluation_models import Evaluation
from ..middleware import roles_required

# Schemas
from ..schemas.intern_schema import InternCreateSchema, InternUpdateSchema, InternOutSchema

bp = Blueprint("interns", __name__)


@bp.post("/intern-profiles")
@roles_required("Admin", "HR")
def create_intern_profile():
    """
    Create intern profile
    ---
    tags: [Interns]
    summary: Create intern profile
    description: Tạo hồ sơ thực tập sinh (1-1 với User có role=Intern).
    parameters:
      - in: body
        name: body
        required: true
        schema:
          type: object
          required: [userID, skill]
          properties:
            userID:
              type: integer
              example: 3
            skill:
              type: string
              example: "Python, SQL"
    responses:
      201:
        description: Created
        schema:
          $ref: "#/definitions/OkWrapper"
        headers:
          Location:
            type: string
            description: Resource URL of the created intern profile
      400:
        description: Bad request
        schema:
          $ref: "#/definitions/Error"
      401:
        description: Unauthorized / Forbidden
        schema:
          $ref: "#/definitions/Error"
      409:
        description: Conflict (duplicate 1-1 with user, hoặc user không hợp lệ)
        schema:
          $ref: "#/definitions/Error"
    """
    payload = InternCreateSchema().load(get_json(required=True))
    prof = InternProfile(**payload)
    g.db.add(prof)
    g.db.flush()
    return created(InternOutSchema().dump(prof), location=f"/api/intern-profiles/{prof.internID}")


@bp.get("/intern-profiles/<int:intern_id>")
@roles_required("Admin", "HR")
def get_intern_profile(intern_id: int):
    """
    Get intern profile by ID
    ---
    tags: [Interns]
    summary: Get intern profile by ID
    parameters:
      - in: path
        name: intern_id
        type: integer
        required: true
        description: InternProfile ID
    responses:
      200:
        description: OK
        schema:
          $ref: "#/definitions/OkWrapper"
      401:
        description: Unauthorized / Forbidden
        schema:
          $ref: "#/definitions/Error"
      404:
        description: Not Found
        schema:
          $ref: "#/definitions/Error"
    """
    prof = g.db.get(InternProfile, intern_id)
    if not prof:
        raise NotFoundError("InternProfile not found")
    return ok(InternOutSchema().dump(prof))


@bp.get("/intern-profiles")
@roles_required("Admin", "HR")
def list_intern_profiles():
    """
    List intern profiles
    ---
    tags: [Interns]
    summary: List intern profiles
    description: Liệt kê hồ sơ thực tập sinh, hỗ trợ lọc theo `userID` và phân trang.
    parameters:
      - in: query
        name: userID
        type: integer
        description: Filter theo userID
      - in: query
        name: limit
        type: integer
        default: 50
        description: Page size
      - in: query
        name: offset
        type: integer
        default: 0
        description: Offset
    responses:
      200:
        description: OK
        schema:
          type: object
          properties:
            success:
              type: boolean
              example: true
            data:
              type: array
              items:
                type: object
                properties:
                  internID: { type: integer, example: 5 }
                  userID:   { type: integer, example: 3 }
                  skill:    { type: string,  example: "Python, SQL" }
            meta:
              $ref: "#/definitions/Pagination"
      401:
        description: Unauthorized / Forbidden
        schema:
          $ref: "#/definitions/Error"
    """
    limit, offset = pg()
    user_id = qint("userID")
    q = g.db.query(InternProfile)
    if user_id is not None:
        q = q.filter(InternProfile.userID == user_id)
    total = q.count()
    items = (
        q.order_by(InternProfile.internID.asc())
         .offset(offset).limit(limit).all()
    )
    return paginated(InternOutSchema(many=True).dump(items), total=total, limit=limit, offset=offset)


@bp.put("/intern-profiles/<int:intern_id>")
@roles_required("Admin", "HR")
def update_intern_profile(intern_id: int):
    """
    Update intern profile
    ---
    tags: [Interns]
    summary: Update intern profile
    parameters:
      - in: path
        name: intern_id
        type: integer
        required: true
        description: InternProfile ID
      - in: body
        name: body
        required: true
        schema:
          type: object
          properties:
            skill:
              type: string
              example: "Python, SQL, Docker"
    responses:
      200:
        description: OK
        schema:
          $ref: "#/definitions/OkWrapper"
      401:
        description: Unauthorized / Forbidden
        schema:
          $ref: "#/definitions/Error"
      404:
        description: Not Found
        schema:
          $ref: "#/definitions/Error"
    """
    prof = g.db.get(InternProfile, intern_id)
    if not prof:
        raise NotFoundError("InternProfile not found")
    data = InternUpdateSchema().load(get_json(required=True), context={"db": g.db})
    for k, v in data.items():
        setattr(prof, k, v)
    return ok(InternOutSchema().dump(prof))


@bp.delete("/intern-profiles/<int:intern_id>")
@roles_required("Admin", "HR")
def delete_intern_profile(intern_id: int):
    """
    Delete intern profile
    ---
    tags: [Interns]
    summary: Delete intern profile
    description: Chỉ xóa khi **không còn** Assignment/Evaluation tham chiếu tới intern.
    parameters:
      - in: path
        name: intern_id
        type: integer
        required: true
        description: InternProfile ID
    responses:
      204:
        description: No Content
      401:
        description: Unauthorized / Forbidden
        schema:
          $ref: "#/definitions/Error"
      404:
        description: Not Found
        schema:
          $ref: "#/definitions/Error"
      409:
        description: Conflict (has Assignments/Evaluations)
        schema:
          $ref: "#/definitions/Error"
    """
    prof = g.db.get(InternProfile, intern_id)
    if not prof:
        raise NotFoundError("InternProfile not found")
    if g.db.query(Assignment).filter_by(internID=intern_id).count() > 0:
        raise ConflictError("Cannot delete InternProfile with Assignments")
    if g.db.query(Evaluation).filter_by(internID=intern_id).count() > 0:
        raise ConflictError("Cannot delete InternProfile with Evaluations")
    g.db.delete(prof)
    return no_content()
