from __future__ import annotations

from flask import Blueprint, g
from ..responses import no_content
from ...error_handler import NotFoundError, ConflictError
from ...infrastructure.models.training_models import Project
from ...infrastructure.models.work_models import Assignment
from ..middleware import roles_required

bp = Blueprint("projects_admin", __name__)


@bp.delete("/projects/<int:proj_id>")
@roles_required("Admin", "HR", "Coordinator")
def delete_project(proj_id: int):
    """
    Delete a project
    ---
    tags:
      - Projects
    summary: Delete a project
    description: Delete a project **only if** there are no assignments under it.
    parameters:
      - in: path
        name: proj_id
        type: integer
        required: true
        description: Project ID
    responses:
      204:
        description: No Content (deleted)
      401:
        description: Unauthorized / Forbidden (role)
        schema:
          $ref: "#/definitions/Error"
      404:
        description: Project not found
        schema:
          $ref: "#/definitions/Error"
      409:
        description: Cannot delete project that still has assignments
        schema:
          $ref: "#/definitions/Error"
    """
    pr = g.db.get(Project, proj_id)
    if not pr:
        raise NotFoundError("Project not found")
    if g.db.query(Assignment).filter_by(projID=proj_id).count() > 0:
        raise ConflictError("Cannot delete Project with Assignments")
    g.db.delete(pr)
    return no_content()
