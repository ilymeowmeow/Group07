from __future__ import annotations

from flask import Blueprint, g
from ..responses import ok, created, paginated, no_content
from ..requests import get_json, qstr, pagination as pg
from ...error_handler import NotFoundError, ConflictError
from ...infrastructure.models.recruitment_models import RecruitmentCampaign, Application
from ...enums import CampaignStatus
from ..middleware import roles_required, jwt_required

# Schemas
from ..schemas.recruitment_schema import (
    CampaignCreateSchema, CampaignUpdateSchema, CampaignOutSchema
)

bp = Blueprint("campaigns", __name__)


@bp.post("/campaigns")
@roles_required("Admin", "HR")
def create_campaign():
    """
    Create a recruitment campaign
    ---
    tags: [Campaigns]
    summary: Create a recruitment campaign
    parameters:
      - in: body
        name: body
        required: true
        schema:
          type: object
          required: [title]
          properties:
            title:
              type: string
              example: "Summer 2026"
            status:
              type: string
              enum: [Open, Closed]
              example: "Open"
    responses:
      201:
        description: Created
        schema:
          $ref: "#/definitions/OkWrapper"
        headers:
          Location:
            type: string
            description: Resource URL of the created campaign
      400:
        description: Bad request
        schema:
          $ref: "#/definitions/Error"
      401:
        description: Unauthorized / Forbidden
        schema:
          $ref: "#/definitions/Error"
      409:
        description: Conflict
        schema:
          $ref: "#/definitions/Error"
    """
    payload = CampaignCreateSchema().load(get_json(required=True))
    camp = RecruitmentCampaign(**payload)
    g.db.add(camp)
    g.db.flush()
    return created(CampaignOutSchema().dump(camp), location=f"/api/campaigns/{camp.campID}")


@bp.get("/campaigns/<int:camp_id>")
@jwt_required(optional=True)  # public read
def get_campaign(camp_id: int):
    """
    Get a campaign by ID
    ---
    tags: [Campaigns]
    summary: Get a campaign by ID
    parameters:
      - in: path
        name: camp_id
        type: integer
        required: true
        description: Campaign ID
    responses:
      200:
        description: OK
        schema:
          $ref: "#/definitions/OkWrapper"
      404:
        description: Not Found
        schema:
          $ref: "#/definitions/Error"
    """
    camp = g.db.get(RecruitmentCampaign, camp_id)
    if not camp:
        raise NotFoundError("Campaign not found")
    return ok(CampaignOutSchema().dump(camp))


@bp.get("/campaigns")
@jwt_required(optional=True)  # public list
def list_campaigns():
    """
    List campaigns
    ---
    tags: [Campaigns]
    summary: List campaigns
    parameters:
      - in: query
        name: status
        type: string
        enum: [Open, Closed]
        description: Filter by status
      - in: query
        name: limit
        type: integer
        default: 50
        description: Page size
      - in: query
        name: offset
        type: integer
        default: 0
        description: Offset for pagination
    responses:
      200:
        description: OK
        schema:
          type: object
          properties:
            success:
              type: boolean
              example: true
            data:
              type: array
              items:
                type: object
                properties:
                  campID: { type: integer, example: 1 }
                  title:  { type: string,  example: "Summer 2026" }
                  status:
                    type: string
                    enum: [Open, Closed]
                    example: "Open"
            meta:
              $ref: "#/definitions/Pagination"
    """
    limit, offset = pg()
    status = qstr("status")
    q = g.db.query(RecruitmentCampaign)
    if status:
        q = q.filter(RecruitmentCampaign.status == status)
    total = q.count()
    items = (
        q.order_by(RecruitmentCampaign.campID.asc())
         .offset(offset).limit(limit).all()
    )
    return paginated(CampaignOutSchema(many=True).dump(items), total=total, limit=limit, offset=offset)


@bp.put("/campaigns/<int:camp_id>")
@roles_required("Admin", "HR")
def update_campaign(camp_id: int):
    """
    Update a campaign
    ---
    tags: [Campaigns]
    summary: Update a campaign
    parameters:
      - in: path
        name: camp_id
        type: integer
        required: true
        description: Campaign ID
      - in: body
        name: body
        required: true
        schema:
          type: object
          properties:
            title:  { type: string, example: "Summer 2026 (updated)" }
            status: { type: string, enum: [Open, Closed], example: "Open" }
    responses:
      200:
        description: OK
        schema:
          $ref: "#/definitions/OkWrapper"
      400:
        description: Bad request
        schema:
          $ref: "#/definitions/Error"
      401:
        description: Unauthorized / Forbidden
        schema:
          $ref: "#/definitions/Error"
      404:
        description: Not Found
        schema:
          $ref: "#/definitions/Error"
    """
    camp = g.db.get(RecruitmentCampaign, camp_id)
    if not camp:
        raise NotFoundError("Campaign not found")
    data = CampaignUpdateSchema().load(get_json(required=True))
    for k, v in data.items():
        setattr(camp, k, v)
    return ok(CampaignOutSchema().dump(camp))


@bp.delete("/campaigns/<int:camp_id>")
@roles_required("Admin", "HR")
def delete_campaign(camp_id: int):
    """
    Delete a campaign
    ---
    tags: [Campaigns]
    summary: Delete a campaign
    parameters:
      - in: path
        name: camp_id
        type: integer
        required: true
        description: Campaign ID
    responses:
      204:
        description: No Content
      401:
        description: Unauthorized / Forbidden
        schema:
          $ref: "#/definitions/Error"
      404:
        description: Not Found
        schema:
          $ref: "#/definitions/Error"
      409:
        description: Conflict (has applications)
        schema:
          $ref: "#/definitions/Error"
    """
    camp = g.db.get(RecruitmentCampaign, camp_id)
    if not camp:
        raise NotFoundError("Campaign not found")
    if g.db.query(Application).filter_by(campID=camp_id).count() > 0:
        raise ConflictError("Cannot delete campaign with Applications")
    g.db.delete(camp)
    return no_content()


@bp.post("/campaigns/<int:camp_id>/close")
@roles_required("Admin", "HR")
def close_campaign(camp_id: int):
    """
    Close a campaign
    ---
    tags: [Campaigns]
    summary: Close a campaign
    parameters:
      - in: path
        name: camp_id
        type: integer
        required: true
        description: Campaign ID
    responses:
      200:
        description: OK
        schema:
          $ref: "#/definitions/OkWrapper"
      401:
        description: Unauthorized / Forbidden
        schema:
          $ref: "#/definitions/Error"
      404:
        description: Not Found
        schema:
          $ref: "#/definitions/Error"
    """
    camp = g.db.get(RecruitmentCampaign, camp_id)
    if not camp:
        raise NotFoundError("Campaign not found")
    camp.status = CampaignStatus.Closed.value
    return ok(CampaignOutSchema().dump(camp))
