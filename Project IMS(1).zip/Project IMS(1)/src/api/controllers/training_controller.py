from __future__ import annotations

from flask import Blueprint, g
from ..responses import ok, created, paginated, no_content
from ..requests import get_json, qint, pagination as pg
from ...error_handler import NotFoundError, ConflictError
from ...infrastructure.models.training_models import TrainingProgram, Project
from ..middleware import roles_required, jwt_required

# Schemas
from ..schemas.training_schema import ProgramCreateSchema, ProgramUpdateSchema, ProgramOutSchema
from ..schemas.project_schema import ProjectCreateSchema, ProjectOutSchema

bp = Blueprint("training", __name__)

# ---------- Programs ----------

@bp.post("/programs")
@roles_required("Admin", "HR", "Coordinator")
def create_program():
    """
    Create a training program
    ---
    tags: [Programs]
    summary: Create a training program
    parameters:
      - in: body
        name: body
        required: true
        schema:
          type: object
          required: [title]
          properties:
            title:
              type: string
              example: Backend Bootcamp
            goal:
              type: string
              example: API fundamentals, SQL, testing
    responses:
      201:
        description: Created
        schema:
          $ref: "#/definitions/OkWrapper"
        headers:
          Location:
            type: string
            description: Resource URL of the created program
      400:
        description: Bad request
        schema:
          $ref: "#/definitions/Error"
      401:
        description: Unauthorized / Forbidden
        schema:
          $ref: "#/definitions/Error"
    """
    payload = ProgramCreateSchema().load(get_json(required=True))
    p = TrainingProgram(**payload)
    g.db.add(p)
    g.db.flush()
    return created(ProgramOutSchema().dump(p), location=f"/api/programs/{p.progID}")


@bp.get("/programs/<int:prog_id>")
@jwt_required(optional=True)  # public read
def get_program(prog_id: int):
    """
    Get a program by ID
    ---
    tags: [Programs]
    summary: Get a program by ID
    parameters:
      - in: path
        name: prog_id
        type: integer
        required: true
        description: Program ID
    responses:
      200:
        description: OK
        schema:
            $ref: "#/definitions/OkWrapper"
      404:
        description: Not Found
        schema:
            $ref: "#/definitions/Error"
    """
    p = g.db.get(TrainingProgram, prog_id)
    if not p:
        raise NotFoundError("Program not found")
    return ok(ProgramOutSchema().dump(p))


@bp.get("/programs")
@jwt_required(optional=True)  # public list
def list_programs():
    """
    List training programs
    ---
    tags: [Programs]
    summary: List training programs
    parameters:
      - in: query
        name: limit
        type: integer
        default: 50
        description: Page size
      - in: query
        name: offset
        type: integer
        default: 0
        description: Offset for pagination
    responses:
      200:
        description: OK
        schema:
          type: object
          properties:
            success:
              type: boolean
              example: true
            data:
              type: array
              items:
                type: object
                properties:
                  progID: { type: integer, example: 1 }
                  title:  { type: string,  example: "Backend Bootcamp" }
                  goal:   { type: string,  example: "API fundamentals, SQL, testing" }
            meta:
              $ref: "#/definitions/Pagination"
    """
    limit, offset = pg()
    q = g.db.query(TrainingProgram)
    total = q.count()
    items = (
        q.order_by(TrainingProgram.progID.asc())
         .offset(offset).limit(limit).all()
    )
    return paginated(ProgramOutSchema(many=True).dump(items), total=total, limit=limit, offset=offset)


@bp.put("/programs/<int:prog_id>")
@roles_required("Admin", "HR", "Coordinator")
def update_program(prog_id: int):
    """
    Update a training program
    ---
    tags: [Programs]
    summary: Update a training program
    parameters:
      - in: path
        name: prog_id
        type: integer
        required: true
        description: Program ID
      - in: body
        name: body
        required: true
        schema:
          type: object
          properties:
            title:
              type: string
              example: Backend Bootcamp (v2)
            goal:
              type: string
              example: Add caching & message queue
    responses:
      200:
        description: OK
        schema:
          $ref: "#/definitions/OkWrapper"
      400:
        description: Bad request
        schema:
          $ref: "#/definitions/Error"
      401:
        description: Unauthorized / Forbidden
        schema:
          $ref: "#/definitions/Error"
      404:
        description: Not Found
        schema:
          $ref: "#/definitions/Error"
    """
    p = g.db.get(TrainingProgram, prog_id)
    if not p:
        raise NotFoundError("Program not found")
    data = ProgramUpdateSchema().load(get_json(required=True))
    for k, v in data.items():
        setattr(p, k, v)
    return ok(ProgramOutSchema().dump(p))


@bp.delete("/programs/<int:prog_id>")
@roles_required("Admin", "HR", "Coordinator")
def delete_program(prog_id: int):
    """
    Delete a training program
    ---
    tags: [Programs]
    summary: Delete a training program
    description: Only allowed if no Project exists under the program.
    parameters:
      - in: path
        name: prog_id
        type: integer
        required: true
        description: Program ID
    responses:
      204:
        description: No Content
      401:
        description: Unauthorized / Forbidden
        schema:
          $ref: "#/definitions/Error"
      404:
        description: Not Found
        schema:
          $ref: "#/definitions/Error"
      409:
        description: Conflict (program has projects)
        schema:
          $ref: "#/definitions/Error"
    """
    p = g.db.get(TrainingProgram, prog_id)
    if not p:
        raise NotFoundError("Program not found")
    if g.db.query(Project).filter_by(progID=prog_id).count() > 0:
        raise ConflictError("Cannot delete Program with Projects")
    g.db.delete(p)
    return no_content()

# ---------- Projects ----------

@bp.post("/projects")
@roles_required("Admin", "HR", "Coordinator")
def create_project():
    """
    Create a project under a program
    ---
    tags: [Projects]
    summary: Create a project under a program
    parameters:
      - in: body
        name: body
        required: true
        schema:
          type: object
          required: [progID, title]
          properties:
            progID:
              type: integer
              example: 1
            title:
              type: string
              example: REST API Server
    responses:
      201:
        description: Created
        schema:
          $ref: "#/definitions/OkWrapper"
        headers:
          Location:
            type: string
            description: Resource URL of the created project
      400:
        description: Bad request
        schema:
          $ref: "#/definitions/Error"
      401:
        description: Unauthorized / Forbidden
        schema:
          $ref: "#/definitions/Error"
      404:
        description: Program not found
        schema:
          $ref: "#/definitions/Error"
    """
    payload = ProjectCreateSchema().load(get_json(required=True))
    pr = Project(**payload)
    g.db.add(pr)
    g.db.flush()
    return created(ProjectOutSchema().dump(pr), location=f"/api/projects/{pr.projID}")


@bp.get("/projects/<int:proj_id>")
@jwt_required(optional=True)  # public read
def get_project(proj_id: int):
    """
    Get a project by ID
    ---
    tags: [Projects]
    summary: Get a project by ID
    parameters:
      - in: path
        name: proj_id
        type: integer
        required: true
        description: Project ID
    responses:
      200:
        description: OK
        schema:
          $ref: "#/definitions/OkWrapper"
      404:
        description: Not Found
        schema:
          $ref: "#/definitions/Error"
    """
    pr = g.db.get(Project, proj_id)
    if not pr:
        raise NotFoundError("Project not found")
    return ok(ProjectOutSchema().dump(pr))


@bp.get("/projects")
@jwt_required(optional=True)  # public list
def list_projects():
    """
    List projects
    ---
    tags: [Projects]
    summary: List projects
    parameters:
      - in: query
        name: progID
        type: integer
        required: false
        description: Filter by program ID
      - in: query
        name: limit
        type: integer
        default: 50
        description: Page size
      - in: query
        name: offset
        type: integer
        default: 0
        description: Offset for pagination
    responses:
      200:
        description: OK
        schema:
          type: object
          properties:
            success:
              type: boolean
              example: true
            data:
              type: array
              items:
                type: object
                properties:
                  projID: { type: integer, example: 10 }
                  progID: { type: integer, example: 1 }
                  title:  { type: string,  example: "REST API Server" }
            meta:
              $ref: "#/definitions/Pagination"
    """
    limit, offset = pg()
    prog_id = qint("progID")
    q = g.db.query(Project)
    if prog_id is not None:
        q = q.filter(Project.progID == prog_id)
    total = q.count()
    items = (
        q.order_by(Project.projID.asc())
         .offset(offset).limit(limit).all()
    )
    return paginated(ProjectOutSchema(many=True).dump(items), total=total, limit=limit, offset=offset)
