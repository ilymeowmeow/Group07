from __future__ import annotations

from flask import Blueprint, g
from ..responses import ok, created, paginated, no_content
from ..requests import get_json, qstr, pagination as pg
from ...error_handler import NotFoundError, ConflictError
from ...infrastructure.models.identity_models import User, InternProfile
from ...infrastructure.models.recruitment_models import Application
from ..middleware import roles_required

# Schemas
from ..schemas.user_schema import UserCreateSchema, UserUpdateSchema, UserOutSchema

bp = Blueprint("users", __name__)


@bp.post("/users")
@roles_required("Admin", "HR")
def create_user():
    """
    Create user
    ---
    tags: [Users]
    summary: Create a user
    description: Create a new user with unique email and valid role.
    parameters:
      - in: body
        name: body
        required: true
        schema:
          type: object
          required: [email, role]
          properties:
            name:
              type: string
              example: Alice
            email:
              type: string
              example: alice@corp.com
            role:
              type: string
              enum: [Admin, HR, Coordinator, Mentor, Intern]
              example: HR
    responses:
      201:
        description: Created
        schema:
          $ref: "#/definitions/OkWrapper"
        headers:
          Location:
            type: string
            description: Resource URL of the created user
      400:
        description: Bad request
        schema:
          $ref: "#/definitions/Error"
      401:
        description: Unauthorized / Forbidden
        schema:
          $ref: "#/definitions/Error"
      409:
        description: Duplicate email
        schema:
          $ref: "#/definitions/Error"
    """
    payload = UserCreateSchema().load(get_json())
    user = User(**payload)
    g.db.add(user)
    g.db.flush()
    return created(UserOutSchema().dump(user), location=f"/api/users/{user.userID}")


@bp.get("/users/<int:user_id>")
@roles_required("Admin", "HR")
def get_user(user_id: int):
    """
    Get user by ID
    ---
    tags: [Users]
    summary: Get a user by ID
    parameters:
      - in: path
        name: user_id
        type: integer
        required: true
        description: User ID
    responses:
      200:
        description: OK
        schema:
          $ref: "#/definitions/OkWrapper"
      401:
        description: Unauthorized / Forbidden
        schema:
          $ref: "#/definitions/Error"
      404:
        description: Not Found
        schema:
          $ref: "#/definitions/Error"
    """
    user = g.db.get(User, user_id)
    if not user:
        raise NotFoundError("User not found")
    return ok(UserOutSchema().dump(user))


@bp.get("/users")
@roles_required("Admin", "HR")
def list_users():
    """
    List users
    ---
    tags: [Users]
    summary: List users
    description: List users with optional role filter and pagination.
    parameters:
      - in: query
        name: role
        type: string
        enum: [Admin, HR, Coordinator, Mentor, Intern]
        description: Filter by role
      - in: query
        name: limit
        type: integer
        default: 50
        description: Page size
      - in: query
        name: offset
        type: integer
        default: 0
        description: Offset for pagination
    responses:
      200:
        description: OK
        schema:
          type: object
          properties:
            success:
              type: boolean
              example: true
            data:
              type: array
              items:
                type: object
                properties:
                  userID: { type: integer, example: 1 }
                  name:   { type: string,  example: "Alice" }
                  email:  { type: string,  example: "alice@corp.com" }
                  role:
                    type: string
                    enum: [Admin, HR, Coordinator, Mentor, Intern]
                    example: HR
            meta:
              $ref: "#/definitions/Pagination"
      401:
        description: Unauthorized / Forbidden
        schema:
          $ref: "#/definitions/Error"
    """
    limit, offset = pg()
    role = qstr("role")
    q = g.db.query(User)
    if role:
        q = q.filter(User.role == role)
    total = q.count()
    items = (
        q.order_by(User.userID.asc())
         .offset(offset).limit(limit).all()
    )
    return paginated(UserOutSchema(many=True).dump(items), total=total, limit=limit, offset=offset)


@bp.put("/users/<int:user_id>")
@roles_required("Admin", "HR")
def update_user(user_id: int):
    """
    Update user
    ---
    tags: [Users]
    summary: Update a user
    description: Update user's name/email/role.
    parameters:
      - in: path
        name: user_id
        type: integer
        required: true
        description: User ID
      - in: body
        name: body
        required: true
        schema:
          type: object
          properties:
            name:  { type: string,  example: "Alice B." }
            email: { type: string,  example: "alice.b@corp.com" }
            role:
              type: string
              enum: [Admin, HR, Coordinator, Mentor, Intern]
              example: HR
    responses:
      200:
        description: OK
        schema:
          $ref: "#/definitions/OkWrapper"
      400:
        description: Bad request
        schema:
          $ref: "#/definitions/Error"
      401:
        description: Unauthorized / Forbidden
        schema:
          $ref: "#/definitions/Error"
      404:
        description: Not Found
        schema:
          $ref: "#/definitions/Error"
      409:
        description: Conflict (duplicate email)
        schema:
          $ref: "#/definitions/Error"
    """
    user = g.db.get(User, user_id)
    if not user:
        raise NotFoundError("User not found")
    data = UserUpdateSchema().load(get_json(required=True), context={"db": g.db})
    for k, v in data.items():
        setattr(user, k, v)
    return ok(UserOutSchema().dump(user))


@bp.delete("/users/<int:user_id>")
@roles_required("Admin", "HR")
def delete_user(user_id: int):
    """
    Delete user
    ---
    tags: [Users]
    summary: Delete a user
    description: Delete a user only if no related Application or InternProfile exists.
    parameters:
      - in: path
        name: user_id
        type: integer
        required: true
        description: User ID
    responses:
      204:
        description: No Content
      401:
        description: Unauthorized / Forbidden
        schema:
          $ref: "#/definitions/Error"
      404:
        description: Not Found
        schema:
          $ref: "#/definitions/Error"
      409:
        description: Conflict (user has Applications or InternProfile)
        schema:
          $ref: "#/definitions/Error"
    """
    user = g.db.get(User, user_id)
    if not user:
        raise NotFoundError("User not found")
    # Ràng buộc tham chiếu
    if g.db.query(Application).filter_by(userID=user_id).count() > 0:
        raise ConflictError("Cannot delete user with Applications")
    if g.db.query(InternProfile).filter_by(userID=user_id).first():
        raise ConflictError("Cannot delete user with InternProfile")
    g.db.delete(user)
    return no_content()
