# src/api/middleware.py
from __future__ import annotations
from functools import wraps
from typing import Iterable, Optional

def init_auth_middleware(app):
    """No-op: không gắn bất kỳ middleware xác thực nào."""
    return

def current_user():
    """No-op: luôn không có user hiện tại."""
    return None

def jwt_required(roles: Optional[Iterable[str]] = None, optional: bool = False):
    """Decorator no-op: luôn cho phép truy cập."""
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            return fn(*args, **kwargs)
        return wrapper
    return decorator

def roles_required(*roles: str):
    """Giữ API tương thích, nhưng không kiểm tra quyền."""
    return jwt_required(roles=list(roles))

def build_dev_token(sub: int, role: str, name: str = "", email: str = "", exp_seconds: int = 3600) -> str:
    """Giữ hàm để code gọi không lỗi; không tạo JWT thật."""
    return "NOAUTH"
