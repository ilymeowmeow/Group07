# src/api/requests.py
from __future__ import annotations
from typing import Any, Tuple, Optional

from flask import request

# Sử dụng hằng phân trang từ domain
from ..domain.constants import DEFAULT_PAGE_SIZE, MAX_PAGE_SIZE

# Nếu bạn dùng App ValidationError trong error_handler
from ..error_handler import ValidationError


def get_json(required: bool = False) -> dict:
    """Đọc JSON body an toàn. required=True -> 422 nếu body rỗng."""
    data = request.get_json(silent=True)
    if required and (data is None or data == {}):
        raise ValidationError("Empty request body")
    return data or {}


def qstr(name: str, default: Optional[str] = None) -> Optional[str]:
    v = request.args.get(name, type=str)
    return v if v is not None and v != "" else default


def qint(name: str, default: Optional[int] = None) -> Optional[int]:
    v = request.args.get(name, type=int)
    return v if v is not None else default


def qbool(name: str, default: Optional[bool] = None) -> Optional[bool]:
    raw = request.args.get(name)
    if raw is None:
        return default
    s = raw.strip().lower()
    if s in ("1", "true", "t", "yes", "y", "on"):
        return True
    if s in ("0", "false", "f", "no", "n", "off"):
        return False
    return default


def pagination() -> Tuple[int, int]:
    """
    Trả về (limit, offset). Hỗ trợ cả 2 kiểu:
    - page & pageSize (ưu tiên)
    - limit & offset
    Dùng DEFAULT_PAGE_SIZE / MAX_PAGE_SIZE từ domain.constants
    """
    # page/pageSize nếu có
    page = qint("page")
    page_size = qint("pageSize", DEFAULT_PAGE_SIZE)
    if page_size and page_size > MAX_PAGE_SIZE:
        page_size = MAX_PAGE_SIZE

    if page is not None:
        if page <= 0:
            raise ValidationError("page must be >= 1")
        if page_size <= 0:
            raise ValidationError("pageSize must be > 0")
        limit = page_size
        offset = (page - 1) * page_size
        return limit, offset

    # ngược lại: limit/offset
    limit = qint("limit", DEFAULT_PAGE_SIZE)
    offset = qint("offset", 0)
    if limit <= 0:
        raise ValidationError("limit must be > 0")
    if limit > MAX_PAGE_SIZE:
        limit = MAX_PAGE_SIZE
    if offset < 0:
        offset = 0
    return limit, offset


def parse_sort(default: Optional[list[tuple[str, str]]] = None) -> list[tuple[str, str]]:
    """
    Đọc sort từ query: ?sort=field1:asc,field2:desc
    Trả list[(field, dir)] với dir ∈ {"asc","desc"}.
    """
    spec = qstr("sort")
    if not spec:
        return default or []
    pairs: list[tuple[str, str]] = []
    for token in spec.split(","):
        token = token.strip()
        if not token:
            continue
        if ":" in token:
            f, d = token.split(":", 1)
            d = d.lower()
            if d not in ("asc", "desc"):
                d = "asc"
        else:
            f, d = token, "asc"
        pairs.append((f.strip(), d))
    return pairs
