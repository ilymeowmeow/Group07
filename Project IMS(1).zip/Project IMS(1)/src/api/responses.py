# src/api/responses.py
from __future__ import annotations

from typing import Any, Dict, Iterable, Optional, Tuple

from flask import jsonify

JsonResp = Tuple[Any, int] | Tuple[Any, int, Dict[str, str]]


def ok(data: Any = None, **meta) -> JsonResp:
    payload: Dict[str, Any] = {"success": True, "data": data}
    if meta:
        payload["meta"] = meta
    return jsonify(payload), 200


def created(data: Any = None, location: Optional[str] = None) -> JsonResp:
    payload = {"success": True, "data": data}
    if location:
        return jsonify(payload), 201, {"Location": location}
    return jsonify(payload), 201


def accepted(data: Any = None) -> JsonResp:
    return jsonify({"success": True, "data": data}), 202


def no_content() -> JsonResp:
    return "", 204


def paginated(items: Iterable[Any], *, total: int, limit: int, offset: int) -> JsonResp:
    page = (offset // limit + 1) if limit else 1
    return ok(list(items), total=total, limit=limit, offset=offset, page=page, pageSize=limit)


def error(status: int, message: str, *, code: Optional[str] = None, details: Any = None) -> JsonResp:
    payload: Dict[str, Any] = {"success": False, "message": message}
    if code:
        payload["code"] = code
    if details is not None:
        payload["details"] = details
    return jsonify(payload), status


__all__ = ["ok", "created", "accepted", "no_content", "paginated", "error"]
