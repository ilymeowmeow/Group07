from .user_schema import UserCreateSchema, UserUpdateSchema, UserOutSchema
from .intern_schema import InternCreateSchema, InternUpdateSchema, InternOutSchema
from .recruitment_schema import CampaignCreateSchema, CampaignUpdateSchema, CampaignOutSchema
from .application_schema import ApplicationCreateSchema, ApplicationOutSchema
from .training_schema import ProgramCreateSchema, ProgramUpdateSchema, ProgramOutSchema
from .project_schema import ProjectCreateSchema, ProjectOutSchema
from .assignment_schema import AssignmentCreateSchema, AssignmentStatusUpdateSchema, AssignmentOutSchema
from .evaluation_schema import EvaluationCreateSchema, EvaluationUpdateSchema, EvaluationOutSchema, AvgScoreOutSchema
