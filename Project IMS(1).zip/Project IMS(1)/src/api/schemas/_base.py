from __future__ import annotations
from marshmallow import Schema, EXCLUDE

class BaseSchema(Schema):
    class Meta:
        ordered = True
        unknown = EXCLUDE  # bỏ qua field thừa trong input

    @property
    def db(self):
        return (self.context or {}).get("db")
