from __future__ import annotations
from marshmallow import fields, validates_schema, ValidationError
from ._base import BaseSchema
from ...enums import CampaignStatus

try:
    from ...infrastructure.models.recruitment_models import RecruitmentCampaign, Application  # noqa
    from ...infrastructure.models.identity_models import User  # noqa
except Exception:
    RecruitmentCampaign = Application = User = None

class ApplicationCreateSchema(BaseSchema):
    campID = fields.Integer(required=True)
    userID = fields.Integer(required=True)

    @validates_schema
    def validate_fk_and_uniqueness(self, data, **kwargs):
        if not self.db or not RecruitmentCampaign or not Application or not User:
            return
        camp = self.db.get(RecruitmentCampaign, int(data["campID"]))
        if not camp:
            raise ValidationError("campID not found", field_name="campID")
        if camp.status != CampaignStatus.Open.value:
            raise ValidationError("Campaign is not Open", field_name="campID")
        if not self.db.get(User, int(data["userID"])):
            raise ValidationError("userID not found", field_name="userID")
        if self.db.query(Application).filter_by(
            campID=int(data["campID"]), userID=int(data["userID"])
        ).first():
            raise ValidationError("Application already exists for (campID,userID)")
        
class ApplicationOutSchema(BaseSchema):
    appID  = fields.Integer()
    campID = fields.Integer()
    userID = fields.Integer()
    status = fields.String()
