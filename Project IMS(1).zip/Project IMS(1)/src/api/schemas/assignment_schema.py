from __future__ import annotations
from marshmallow import fields, validate, validates_schema, ValidationError
from ._base import BaseSchema
from ...enums import AssignmentStatus

try:
    from ...infrastructure.models.training_models import Project  # noqa
    from ...infrastructure.models.identity_models import InternProfile  # noqa
except Exception:
    Project = InternProfile = None

ASSIGN_STATUS = [s.value for s in AssignmentStatus]
ALLOWED = {
    AssignmentStatus.Pending.value: {AssignmentStatus.Doing.value},
    AssignmentStatus.Doing.value: {AssignmentStatus.Done.value},
    AssignmentStatus.Done.value: set(),
}

class AssignmentCreateSchema(BaseSchema):
    projID   = fields.Integer(required=True)
    internID = fields.Integer(required=True)
    status   = fields.String(validate=validate.OneOf(ASSIGN_STATUS),
                             load_default=AssignmentStatus.Pending.value)

    @validates_schema
    def validate_fk(self, data, **kwargs):
        if not self.db:
            return
        if Project and not self.db.get(Project, int(data["projID"])):
            raise ValidationError("projID not found", field_name="projID")
        if InternProfile and not self.db.get(InternProfile, int(data["internID"])):
            raise ValidationError("internID not found", field_name="internID")

class AssignmentStatusUpdateSchema(BaseSchema):
    newStatus = fields.String(required=True, validate=validate.OneOf(ASSIGN_STATUS))

    @validates_schema
    def validate_transition(self, data, **kwargs):
        cur = (self.context or {}).get("current_status")
        if cur and data["newStatus"] not in ALLOWED.get(cur, set()):
            raise ValidationError(f"Invalid transition: {cur} -> {data['newStatus']}", field_name="newStatus")

class AssignmentOutSchema(BaseSchema):
    assignID = fields.Integer()
    projID   = fields.Integer()
    internID = fields.Integer()
    status   = fields.String()
