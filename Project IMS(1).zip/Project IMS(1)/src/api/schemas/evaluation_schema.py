# src/api/schemas/evaluation_schema.py
from __future__ import annotations
from marshmallow import Schema, fields, validates, ValidationError

# Dùng hằng số ràng buộc điểm từ domain
from ...domain.constants import SCORE_MIN, SCORE_MAX


class EvaluationCreateSchema(Schema):
    internID = fields.Int(required=True)
    score = fields.Int(required=True)

    @validates("score")
    def _v_score(self, value, **kwargs):
        if value < SCORE_MIN or value > SCORE_MAX:
            raise ValidationError(f"score must be in [{SCORE_MIN},{SCORE_MAX}]")


class EvaluationUpdateSchema(Schema):
    score = fields.Int(load_default=None)

    @validates("score")
    def _v_score(self, value, **kwargs):
        # Cho phép None khi không cập nhật trường này
        if value is None:
            return
        if value < SCORE_MIN or value > SCORE_MAX:
            raise ValidationError(f"score must be in [{SCORE_MIN},{SCORE_MAX}]")


class EvaluationOutSchema(Schema):
    evalID = fields.Int(dump_only=True)
    internID = fields.Int()
    score = fields.Int()


class AvgScoreOutSchema(Schema):
    internID = fields.Int(required=True)
    avgScore = fields.Float(allow_none=True)
