from __future__ import annotations
from marshmallow import fields, validate, validates_schema, ValidationError
from ._base import BaseSchema
from ...enums import Role

try:
    from ...infrastructure.models.identity_models import User, InternProfile  # noqa
except Exception:
    User = InternProfile = None

class InternCreateSchema(BaseSchema):
    userID = fields.Integer(required=True)
    skill  = fields.String(required=False, allow_none=True, validate=validate.Length(max=500))

    @validates_schema
    def validate_user_role_and_unique(self, data, **kwargs):
        if not self.db or not User:
            return
        user = self.db.get(User, int(data["userID"]))
        if not user:
            raise ValidationError("userID not found", field_name="userID")
        if user.role != Role.Intern.value:
            raise ValidationError("User.role must be Intern", field_name="userID")
        if self.db.query(InternProfile).filter_by(userID=user.userID).first():
            raise ValidationError("InternProfile already exists for this user", field_name="userID")

class InternUpdateSchema(BaseSchema):
    skill = fields.String(required=False, allow_none=True, validate=validate.Length(max=500))

class InternOutSchema(BaseSchema):
    internID = fields.Integer()
    userID   = fields.Integer()
    skill    = fields.String(allow_none=True)
