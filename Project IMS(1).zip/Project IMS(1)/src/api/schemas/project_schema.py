from __future__ import annotations
from marshmallow import fields, validate, validates_schema, ValidationError
from ._base import BaseSchema

try:
    from ...infrastructure.models.training_models import TrainingProgram  # noqa
except Exception:
    TrainingProgram = None

class ProjectCreateSchema(BaseSchema):
    progID = fields.Integer(required=True)
    title  = fields.String(required=True, validate=validate.Length(min=1, max=255))

    @validates_schema
    def validate_prog_exists(self, data, **kwargs):
        if not self.db or not TrainingProgram:
            return
        if not self.db.get(TrainingProgram, int(data["progID"])):
            raise ValidationError("progID not found", field_name="progID")

class ProjectOutSchema(BaseSchema):
    projID = fields.Integer()
    progID = fields.Integer()
    title  = fields.String()
