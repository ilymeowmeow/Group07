from __future__ import annotations
from marshmallow import fields, validate
from ._base import BaseSchema
from ...enums import CampaignStatus

CAMP_STATUS = [CampaignStatus.Open.value, CampaignStatus.Closed.value]

class CampaignCreateSchema(BaseSchema):
    title  = fields.String(required=True, validate=validate.Length(min=1, max=255))
    status = fields.String(validate=validate.OneOf(CAMP_STATUS),
                           load_default=CampaignStatus.Open.value)

class CampaignUpdateSchema(BaseSchema):
    title  = fields.String(required=False, validate=validate.Length(min=1, max=255))
    status = fields.String(required=False, validate=validate.OneOf(CAMP_STATUS))

class CampaignOutSchema(BaseSchema):
    campID = fields.Integer()
    title  = fields.String()
    status = fields.String()
