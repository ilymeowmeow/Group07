from __future__ import annotations
from marshmallow import fields, validate
from ._base import BaseSchema

class ProgramCreateSchema(BaseSchema):
    title = fields.String(required=True, validate=validate.Length(min=1, max=255))
    goal  = fields.String(allow_none=True, validate=validate.Length(max=1000),
                          load_default="")

class ProgramUpdateSchema(BaseSchema):
    title = fields.String(required=False, validate=validate.Length(min=1, max=255))
    goal  = fields.String(required=False, allow_none=True, validate=validate.Length(max=1000))

class ProgramOutSchema(BaseSchema):
    progID = fields.Integer()
    title  = fields.String()
    goal   = fields.String(allow_none=True)
