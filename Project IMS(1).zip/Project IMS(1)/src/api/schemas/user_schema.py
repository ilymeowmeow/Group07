from __future__ import annotations
from marshmallow import fields, validate, validates_schema, ValidationError
from ._base import BaseSchema
from ...enums import Role

try:
    from ...infrastructure.models.identity_models import User  # noqa
except Exception:
    User = None

ROLE_VALUES = [r.value for r in Role]

class UserCreateSchema(BaseSchema):
    name  = fields.String(required=True, validate=validate.Length(min=1, max=200))
    email = fields.Email(required=True, validate=validate.Length(max=255))
    role  = fields.String(required=True, validate=validate.OneOf(ROLE_VALUES))

    @validates_schema
    def validate_unique_email(self, data, **kwargs):
        if self.db and User:
            if self.db.query(User).filter(User.email == data["email"]).first():
                raise ValidationError("Email already exists", field_name="email")

class UserUpdateSchema(BaseSchema):
    name = fields.String(required=False, validate=validate.Length(min=1, max=200))
    role = fields.String(required=False, validate=validate.OneOf(ROLE_VALUES))

class UserOutSchema(BaseSchema):
    userID = fields.Integer()
    name   = fields.String()
    email  = fields.Email()
    role   = fields.String()
