# src/app_logging.py
from __future__ import annotations

import logging
import os
from flask import Flask, request


def init_logging(app: Flask):
    level = os.getenv("LOG_LEVEL", "INFO").upper()
    logging.basicConfig(
        level=getattr(logging, level, logging.INFO),
        format="%(asctime)s %(levelname)s %(name)s :: %(message)s",
    )
    app.logger.setLevel(getattr(logging, level, logging.INFO))

    logging.getLogger("ims.email").setLevel(logging.INFO)


    @app.before_request
    def _log_request():
        app.logger.debug("REQ %s %s", request.method, request.path)
