# src/config.py
from __future__ import annotations

import os
from dotenv import load_dotenv

load_dotenv()  # load .env ở project root


class Config:
    # DB
    SQLALCHEMY_DATABASE_URI = os.getenv("DATABASE_URI") or os.getenv("SQLALCHEMY_DATABASE_URI")
    # App
    SECRET_KEY = os.getenv("SECRET_KEY", "dev-secret")
    DEBUG = os.getenv("FLASK_DEBUG", "1") in ("1", "true", "yes", "on")
    # JWT
    # JWT_SECRET = os.getenv("JWT_SECRET", SECRET_KEY)
    # JWT_ALG = os.getenv("JWT_ALG", "HS256")
    # AUTH_DISABLED = os.getenv("AUTH_DISABLED", "0")
    # CORS
    CORS_ALLOW_ORIGINS = os.getenv("CORS_ALLOW_ORIGINS", "*")

    # Email (tùy chọn)
    EMAIL_BACKEND = os.getenv("EMAIL_BACKEND", "console")  # 'console' | 'smtp'
    EMAIL_FROM = os.getenv("EMAIL_FROM", "no-reply@localhost")

    EMAIL_HOST = os.getenv("EMAIL_HOST")               # smtp host
    EMAIL_PORT = int(os.getenv("EMAIL_PORT", "587"))   # smtp port
    EMAIL_USERNAME = os.getenv("EMAIL_USERNAME")
    EMAIL_PASSWORD = os.getenv("EMAIL_PASSWORD")
    EMAIL_USE_TLS = os.getenv("EMAIL_USE_TLS", "true").lower() == "true"
    EMAIL_USE_SSL = os.getenv("EMAIL_USE_SSL", "false").lower() == "true"