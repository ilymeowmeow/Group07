# src/cors.py
from __future__ import annotations

import os
from flask import Flask, request, make_response


def init_cors(app: Flask):
    origins = os.getenv("CORS_ALLOW_ORIGINS", "*")

    @app.after_request
    def _add_cors_headers(resp):
        resp.headers["Access-Control-Allow-Origin"] = origins
        resp.headers["Access-Control-Allow-Credentials"] = "true"
        resp.headers["Access-Control-Allow-Headers"] = "Authorization, Content-Type"
        resp.headers["Access-Control-Allow-Methods"] = "GET, POST, PUT, PATCH, DELETE, OPTIONS"
        return resp

    @app.route("/__preflight__", methods=["OPTIONS"])
    def _preflight():
        resp = make_response("", 204)
        resp.headers["Access-Control-Allow-Origin"] = origins
        resp.headers["Access-Control-Allow-Credentials"] = "true"
        resp.headers["Access-Control-Allow-Headers"] = "Authorization, Content-Type"
        resp.headers["Access-Control-Allow-Methods"] = "GET, POST, PUT, PATCH, DELETE, OPTIONS"
        return resp
