# src/create_app.py
from __future__ import annotations

from flasgger import Swagger

import importlib
from typing import List, Tuple

from flask import Flask, g, jsonify

from .config import Config
from .error_handler import errors_bp
from .app_logging import init_logging
from .cors import init_cors
from .dependency_container import wire_services

# --- DB (SQLAlchemy) ---
from .infrastructure.databases import init_engine, get_session, Base
# Import models để Base.metadata thấy toàn bộ bảng
from .infrastructure import models as _models  # noqa: F401

# Controllers (module_path, url_prefix)
CONTROLLERS: List[Tuple[str, str]] = [
    ("src.api.controllers.user_controller", "/api"),
    ("src.api.controllers.intern_controller", "/api"),
    ("src.api.controllers.recruitment_controller", "/api"),
    ("src.api.controllers.application_controller", "/api"),
    ("src.api.controllers.training_controller", "/api"),
    ("src.api.controllers.project_controller", "/api"),
    ("src.api.controllers.assignment_controller", "/api"),
    ("src.api.controllers.evaluation_controller", "/api"),
]


def create_app() -> Flask:
    app = Flask(__name__)
    app.config.from_object(Config)

    # ==== Swagger 2.0 (Flasgger 0.9.x) ====
    swagger_template = {
        "swagger": "2.0",
        "info": {
            "title": "IMS API",
            "version": "1.0.0",
            "description": "Intern Management System API documentation",
        },
        "basePath": "/",           # gốc
        "schemes": ["http"],       # nếu dùng HTTPS thì thêm "https"
        # "securityDefinitions": {
        #     "Bearer": {            # kiểu JWT Bearer cho nút Authorize
        #         "type": "apiKey",
        #         "name": "Authorization",
        #         "in": "header",
        #         "description": "Nhập: Bearer <token>"
        #     }
        # },
        
        "consumes": ["application/json"],
        "produces": ["application/json"],

        "definitions": {
            "Pagination": {
                "type": "object",
                "properties": {
                    "limit": {"type": "integer"},
                    "offset": {"type": "integer"},
                    "page": {"type": "integer"},
                    "pageSize": {"type": "integer"},
                    "total": {"type": "integer"}
                }
            },
            "Campaign": {
                "type": "object",
                "properties": {
                    "campID": {"type": "integer"},
                    "title": {"type": "string"},
                    "status": {"type": "string", "enum": ["Open", "Closed"]}
                },
                "required": ["campID", "title", "status"]
            },
            "CampaignCreate": {
                "type": "object",
                "properties": {
                    "title": {"type": "string"},
                    "status": {"type": "string", "enum": ["Open", "Closed"]}
                },
                "required": ["title"]
            },
            "OkWrapper": {
                "type": "object",
                "properties": {
                    "success": {"type": "boolean"},
                    "data": {}
                }
            },
            "ListCampaignsResponse": {
                "type": "object",
                "properties": {
                    "success": {"type": "boolean"},
                    "data": {
                        "type": "array",
                        "items": {"$ref": "#/definitions/Campaign"}
                    },
                    "meta": {"$ref": "#/definitions/Pagination"}
                }
            },
            "Error": {
                "type": "object",
                "properties": {
                    "success": {"type": "boolean"},
                    "code": {"type": "string"},
                    "message": {"type": "string"},
                    "details": {}
                }
            },

            # ===== THÊM MỚI (phục vụ application_controller) =====
            "Application": {
                "type": "object",
                "properties": {
                    "appID":  {"type": "integer"},
                    "campID": {"type": "integer"},
                    "userID": {"type": "integer"},
                    "status": {"type": "string", "enum": ["Pending", "Approved", "Rejected"]}
                },
                "required": ["appID", "campID", "userID", "status"]
            },
            "ApplicationCreate": {
                "type": "object",
                "properties": {
                    "campID": {"type": "integer"},
                    "userID": {"type": "integer"}
                },
                "required": ["campID", "userID"]
            },
            "ListApplicationsResponse": {
                "type": "object",
                "properties": {
                    "success": {"type": "boolean"},
                    "data": {
                        "type": "array",
                        "items": {"$ref": "#/definitions/Application"}
                    },
                    "meta": {"$ref": "#/definitions/Pagination"}
                }
            }
        },
    }

    app.config["SWAGGER"] = {
    "title": "IMS API",
    "uiversion": 3,                 # hiện UI với ô Explore
}

    swagger_config = {
    "headers": [],
    "specs": [
        {
            "endpoint": "apispec_1",
            "route": "/swagger.json",
            # 2 filter dưới giúp luôn include tất cả routes,
            # tránh trường hợp spec rỗng → UI trống
            "rule_filter": lambda rule: True,
            "model_filter": lambda tag: True,
        }
    ],
    "static_url_path": "/flasgger_static",
    "swagger_ui": True,
    "specs_route": "/docs/",
}

    
    Swagger(app, template=swagger_template, config=swagger_config)


    # Logging & CORS
    init_logging(app)
    init_cors(app)
    app.url_map.strict_slashes = False
    app.config.setdefault("JSON_SORT_KEYS", False)

    # Database init & create schema
    db_uri = app.config.get("SQLALCHEMY_DATABASE_URI")
    if not db_uri:
        raise RuntimeError("SQLALCHEMY_DATABASE_URI (DATABASE_URI) is missing in .env / Config.")
    engine = init_engine(db_uri)
    Base.metadata.create_all(bind=engine)
    app.logger.info("DB ready: %s", db_uri)

    # Session per-request
    @app.before_request
    def _open_session():
        g.db = get_session()

    @app.teardown_request
    def _close_session(exc):
        db = getattr(g, "db", None)
        if db is not None:
            try:
                if exc:
                    db.rollback()
                else:
                    db.commit()
            finally:
                db.close()

    # Auth middleware (đặt SAU khi đã đăng ký open_session)
    # from .api.middleware import init_auth_middleware
    # init_auth_middleware(app)

    # Wire services
    wire_services(app)

    # Errors
    app.register_blueprint(errors_bp)

    # Register controllers
    for module_path, prefix in CONTROLLERS:
        _register_blueprint(app, module_path, prefix)

    # Utility routes
    @app.get("/")
    def health():
        return jsonify(ok=True, service="IMS API", docs="/docs/")  # đồng bộ dấu /

    @app.get("/routes")
    def routes_list():
        routes = []
        for rule in app.url_map.iter_rules():
            if rule.endpoint == "static":
                continue
            methods = sorted(m for m in rule.methods if m in {"GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"})
            routes.append({"rule": str(rule), "methods": methods, "endpoint": rule.endpoint})
        return jsonify(routes=routes)


    app.logger.info("IMS API is up. Swagger UI: http://127.0.0.1:5000/docs/  |  Raw routes: /routes")
    return app


def _register_blueprint(app: Flask, module_path: str, url_prefix: str) -> None:
    try:
        mod = importlib.import_module(module_path)
        bp = getattr(mod, "bp")
        app.register_blueprint(bp, url_prefix=url_prefix)
        app.logger.info("Registered blueprint: %s -> %s", module_path, url_prefix)
    except Exception as ex:
        app.logger.warning("Skip blueprint %s (reason: %s)", module_path, ex)
