from src.config import Config
from src.infrastructure.databases.db_base import init_engine, Base

# QUAN TRỌNG: import models để Base.metadata thấy hết bảng
import src.infrastructure.models  # noqa: F401

def main():
    uri = Config.SQLALCHEMY_DATABASE_URI
    if not uri:
        raise RuntimeError("Missing DATABASE_URI")
    engine = init_engine(uri)
    Base.metadata.create_all(bind=engine)  # tạo các bảng chưa có
    print("✔ Created all tables.")

if __name__ == "__main__":
    main()
