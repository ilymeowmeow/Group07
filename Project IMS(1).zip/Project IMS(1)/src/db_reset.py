from src.config import Config
from src.infrastructure.databases.db_base import init_engine, Base
import src.infrastructure.models  # noqa: F401

def main():
    uri = Config.SQLALCHEMY_DATABASE_URI
    if not uri:
        raise RuntimeError("Missing DATABASE_URI")
    engine = init_engine(uri)
    print("⚠ Dropping all tables...")
    Base.metadata.drop_all(bind=engine)    # xoá theo thứ tự FK
    print("✔ Dropped.")
    print("Creating all tables...")
    Base.metadata.create_all(bind=engine)
    print("✔ Created.")
if __name__ == "__main__":
    main()
