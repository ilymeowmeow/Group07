# src/dependency_container.py
from __future__ import annotations

from types import SimpleNamespace
from flask import g, Flask


def wire_services(app: Flask) -> None:
    """
    Gắn các service vào g.svcs cho mỗi request.
    - Các service nghiệp vụ nhận session hiện tại (g.db) đã được create_app mở ra.
    - Email service được khởi tạo 1 lần theo config và dùng lại (singleton).
    Nếu một service chưa implement, gán None để controller không crash.
    """
    # ---- Import mềm các service nghiệp vụ (có thể chưa implement) ----
    try:
        from .services.identity_service import IdentityService  # type: ignore
    except Exception:
        IdentityService = None  # type: ignore
    try:
        from .services.recruitment_service import RecruitmentService  # type: ignore
    except Exception:
        RecruitmentService = None  # type: ignore
    try:
        from .services.training_service import TrainingService  # type: ignore
    except Exception:
        TrainingService = None  # type: ignore
    try:
        from .services.work_service import WorkService  # type: ignore
    except Exception:
        WorkService = None  # type: ignore
    try:
        from .services.evaluation_service import EvaluationService  # type: ignore
    except Exception:
        EvaluationService = None  # type: ignore

    # ---- Email service: tạo 1 lần, dùng lại ----
    email_svc = None
    try:
        from .infrastructure.services import build_email_service  # type: ignore

        email_svc = build_email_service(app)
        app.logger.info("Email service initialized: %s", email_svc.__class__.__name__)
    except Exception as ex:
        app.logger.warning("Email service not available: %s", ex)
        email_svc = None

    # Gắn singleton email service vào app.extensions để nơi khác có thể lấy nếu cần
    app.extensions.setdefault("svcs", {})
    app.extensions["svcs"]["email"] = email_svc

    # ---- Gắn svcs theo từng request (nhận session từ g.db) ----
    @app.before_request
    def _attach_svcs():
        # create_app đã mở g.db; ở đây chỉ lấy ra dùng, không tự mở/đóng thêm
        db = getattr(g, "db", None)

        g.svcs = SimpleNamespace(
            identity=(IdentityService(db) if IdentityService else None),
            recruitment=(RecruitmentService(db) if RecruitmentService else None),
            training=(TrainingService(db) if TrainingService else None),
            work=(WorkService(db) if WorkService else None),
            evaluation=(EvaluationService(db) if EvaluationService else None),
            email=email_svc,  # singleton
        )
