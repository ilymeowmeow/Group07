# src/domain/constants.py
from __future__ import annotations
from typing import Final

# Phân trang (khớp helpers trong src/api/requests.py)
DEFAULT_PAGE_SIZE: Final[int] = 50
MAX_PAGE_SIZE: Final[int] = 200

# Nghiệp vụ Assignment (gợi ý)
MAX_TASK_DOING: Final[int] = 3

# Điểm Evaluation
SCORE_MIN: Final[int] = 0
SCORE_MAX: Final[int] = 100

# Role hợp lệ (tham khảo; enums chính được định nghĩa ở src/enums.py)
ROLES: Final[tuple[str, ...]] = ("Admin", "HR", "Coordinator", "Mentor", "Intern")

# Email format đơn giản (nếu service muốn dùng)
EMAIL_REGEX: Final[str] = r"^[^@\s]+@[^@\s]+\.[^@\s]+$"

__all__ = [
    "DEFAULT_PAGE_SIZE",
    "MAX_PAGE_SIZE",
    "MAX_TASK_DOING",
    "SCORE_MIN",
    "SCORE_MAX",
    "ROLES",
    "EMAIL_REGEX",
]
