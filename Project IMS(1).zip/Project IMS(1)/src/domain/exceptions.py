# src/domain/exceptions.py
from __future__ import annotations
from typing import Any, Optional

__all__ = [
    "DomainError",
    "ValidationError",
    "NotFoundError",
    "ConflictError",
    "ForbiddenError",
    "UnauthorizedError",
    "to_app_error",
]

class DomainError(Exception):
    """
    Lỗi nghiệp vụ (domain). Service/repository nên raise các lỗi kế thừa class này.
    Controller/Flask sẽ map sang AppError/HTTP code bằng to_app_error().
    """
    code = "domain_error"
    def __init__(self, message: str, *, code: Optional[str] = None, details: Any = None):
        super().__init__(message)
        if code:
            self.code = code
        self.details = details


class ValidationError(DomainError):
    code = "validation_error"


class NotFoundError(DomainError):
    code = "not_found"


class ConflictError(DomainError):
    code = "conflict"


class ForbiddenError(DomainError):
    code = "forbidden"


class UnauthorizedError(DomainError):
    code = "unauthorized"


def to_app_error(ex: DomainError):
    """
    Chuyển DomainError -> AppError tương ứng (dùng trong error_handler).
    Import LAZY để tránh circular import với src.error_handler.
    """
    from src.error_handler import (  # lazy import
        AppError,
        ValidationError as AppValidationError,
        NotFoundError as AppNotFoundError,
        ConflictError as AppConflictError,
        ForbiddenError as AppForbiddenError,
        UnauthorizedError as AppUnauthorizedError,
    )

    msg = str(ex)
    details = getattr(ex, "details", None)

    if isinstance(ex, ValidationError):
        return AppValidationError(msg, details=details)
    if isinstance(ex, NotFoundError):
        return AppNotFoundError(msg, details=details)
    if isinstance(ex, ConflictError):
        return AppConflictError(msg, details=details)
    if isinstance(ex, ForbiddenError):
        return AppForbiddenError(msg, details=details)
    if isinstance(ex, UnauthorizedError):
        return AppUnauthorizedError(msg, details=details)

    # Mặc định: AppError(400)
    return AppError(msg, code=getattr(ex, "code", "domain_error"), details=details)
