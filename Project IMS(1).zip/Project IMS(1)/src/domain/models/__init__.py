# src/domain/models/__init__.py
from .user import User
from .intern import InternProfile
from .recruitment import RecruitmentCampaign
from .application import Application
from .training import TrainingProgram
from .project import Project
from .assignment import Assignment
from .evaluation import Evaluation

__all__ = [
    "User",
    "InternProfile",
    "RecruitmentCampaign",
    "Application",
    "TrainingProgram",
    "Project",
    "Assignment",
    "Evaluation",
]
