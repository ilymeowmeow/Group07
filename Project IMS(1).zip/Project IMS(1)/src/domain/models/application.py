# src/domain/models/application.py
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional
from ..exceptions import ValidationError, ConflictError
from ...enums import ApplicationStatus  # Pending, Approved, Rejected

@dataclass(slots=True)
class Application:
    appID: Optional[int] = field(default=None)
    campID: int = field(default=0)
    userID: int = field(default=0)
    status: str = field(default=ApplicationStatus.Pending.value)

    def __post_init__(self) -> None:
        if not isinstance(self.campID, int) or self.campID <= 0:
            raise ValidationError("campID must be positive int", details={"campID": self.campID})
        if not isinstance(self.userID, int) or self.userID <= 0:
            raise ValidationError("userID must be positive int", details={"userID": self.userID})
        valid = {s.value for s in ApplicationStatus}
        if self.status not in valid:
            raise ValidationError(f"status must be one of {valid}", details={"status": self.status})

    def approve(self) -> None:
        if self.status != ApplicationStatus.Pending.value:
            raise ConflictError("can only approve from Pending", details={"status": self.status})
        self.status = ApplicationStatus.Approved.value

    def reject(self) -> None:
        if self.status != ApplicationStatus.Pending.value:
            raise ConflictError("can only reject from Pending", details={"status": self.status})
        self.status = ApplicationStatus.Rejected.value

    def to_dict(self) -> dict:
        return {
            "appID": self.appID,
            "campID": self.campID,
            "userID": self.userID,
            "status": self.status,
        }
