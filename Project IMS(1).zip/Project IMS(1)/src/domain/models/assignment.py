# src/domain/models/assignment.py
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional
from ..exceptions import ValidationError, ConflictError
from ...enums import AssignmentStatus  # Pending, Doing, Done

_ALLOWED = {
    AssignmentStatus.Pending.value: {AssignmentStatus.Doing.value},
    AssignmentStatus.Doing.value: {AssignmentStatus.Done.value},
    AssignmentStatus.Done.value: set(),
}

@dataclass(slots=True)
class Assignment:
    assignID: Optional[int] = field(default=None)
    projID: int = field(default=0)
    internID: int = field(default=0)
    status: str = field(default=AssignmentStatus.Pending.value)

    def __post_init__(self) -> None:
        if not isinstance(self.projID, int) or self.projID <= 0:
            raise ValidationError("projID must be positive int", details={"projID": self.projID})
        if not isinstance(self.internID, int) or self.internID <= 0:
            raise ValidationError("internID must be positive int", details={"internID": self.internID})
        valid = {s.value for s in AssignmentStatus}
        if self.status not in valid:
            raise ValidationError(f"status must be one of {valid}", details={"status": self.status})

    def can_transition(self, new_status: str) -> bool:
        return new_status in _ALLOWED.get(self.status, set())

    def update_status(self, new_status: str) -> None:
        if not self.can_transition(new_status):
            raise ConflictError(
                "invalid status transition",
                details={"from": self.status, "to": new_status}
            )
        self.status = new_status

    def to_dict(self) -> dict:
        return {
            "assignID": self.assignID,
            "projID": self.projID,
            "internID": self.internID,
            "status": self.status,
        }
