# src/domain/models/evaluation.py
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional
from ..constants import SCORE_MIN, SCORE_MAX
from ..exceptions import ValidationError

@dataclass(slots=True)
class Evaluation:
    evalID: Optional[int] = field(default=None)
    internID: int = field(default=0)
    score: int = field(default=0)

    def __post_init__(self) -> None:
        if not isinstance(self.internID, int) or self.internID <= 0:
            raise ValidationError("internID must be positive int", details={"internID": self.internID})
        if not isinstance(self.score, int) or not (SCORE_MIN <= self.score <= SCORE_MAX):
            raise ValidationError(
                f"score must be in [{SCORE_MIN},{SCORE_MAX}]",
                details={"score": self.score}
            )

    def to_dict(self) -> dict:
        return {
            "evalID": self.evalID,
            "internID": self.internID,
            "score": self.score,
        }
