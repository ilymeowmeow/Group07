# src/domain/models/intern.py
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional
from ..exceptions import ValidationError

@dataclass(slots=True)
class InternProfile:
    internID: Optional[int] = field(default=None)
    userID: int = field(default=0)
    skill: str = field(default="")

    def __post_init__(self) -> None:
        if not isinstance(self.userID, int) or self.userID <= 0:
            raise ValidationError("userID must be positive int", details={"userID": self.userID})

    def to_dict(self) -> dict:
        return {
            "internID": self.internID,
            "userID": self.userID,
            "skill": self.skill,
        }
