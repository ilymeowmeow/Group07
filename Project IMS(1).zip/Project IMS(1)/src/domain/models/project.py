# src/domain/models/project.py
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional
from ..exceptions import ValidationError

@dataclass(slots=True)
class Project:
    projID: Optional[int] = field(default=None)
    progID: int = field(default=0)
    title: str = field(default="")

    def __post_init__(self) -> None:
        if not isinstance(self.progID, int) or self.progID <= 0:
            raise ValidationError("progID must be positive int", details={"progID": self.progID})
        if not self.title:
            raise ValidationError("title is required")

    def to_dict(self) -> dict:
        return {
            "projID": self.projID,
            "progID": self.progID,
            "title": self.title,
        }
