# src/domain/models/recruitment.py
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional
from ..exceptions import ValidationError, ConflictError
from ...enums import CampaignStatus  # expects values: Open, Closed

@dataclass(slots=True)
class RecruitmentCampaign:
    campID: Optional[int] = field(default=None)
    title: str = field(default="")
    status: str = field(default=CampaignStatus.Open.value)

    def __post_init__(self) -> None:
        valid = {CampaignStatus.Open.value, CampaignStatus.Closed.value}
        if self.status not in valid:
            raise ValidationError(f"status must be one of {valid}", details={"status": self.status})
        if not self.title:
            raise ValidationError("title is required")

    def close(self) -> None:
        if self.status == CampaignStatus.Closed.value:
            raise ConflictError("campaign already closed")
        self.status = CampaignStatus.Closed.value

    def to_dict(self) -> dict:
        return {
            "campID": self.campID,
            "title": self.title,
            "status": self.status,
        }
