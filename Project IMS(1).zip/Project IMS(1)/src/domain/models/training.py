# src/domain/models/training.py
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional
from ..exceptions import ValidationError

@dataclass(slots=True)
class TrainingProgram:
    progID: Optional[int] = field(default=None)
    title: str = field(default="")
    goal: str = field(default="")

    def __post_init__(self) -> None:
        if not self.title:
            raise ValidationError("title is required")

    def to_dict(self) -> dict:
        return {
            "progID": self.progID,
            "title": self.title,
            "goal": self.goal,
        }
