# src/domain/models/user.py
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional
from ..constants import ROLES, EMAIL_REGEX
from ..exceptions import ValidationError
import re

@dataclass(slots=True)
class User:
    userID: Optional[int] = field(default=None)
    name: str = field(default="")
    email: str = field(default="")
    role: str = field(default="Intern")  # Admin, HR, Coordinator, Mentor, Intern

    def __post_init__(self) -> None:
        if self.role not in ROLES:
            raise ValidationError(f"role must be one of {ROLES}", details={"role": self.role})
        if not self.email or not re.match(EMAIL_REGEX, self.email):
            raise ValidationError("invalid email format", details={"email": self.email})

    def to_dict(self) -> dict:
        return {
            "userID": self.userID,
            "name": self.name,
            "email": self.email,
            "role": self.role,
        }
