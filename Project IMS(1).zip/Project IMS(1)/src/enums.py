from enum import Enum

class Role(str, Enum):
    Admin = "Admin"
    HR = "HR"
    Coordinator = "Coordinator"
    Mentor = "Mentor"
    Intern = "Intern"

class CampaignStatus(str, Enum):
    Open = "Open"
    Closed = "Closed"

class ApplicationStatus(str, Enum):
    Pending = "Pending"
    Approved = "Approved"
    Rejected = "Rejected"

class AssignmentStatus(str, Enum):
    Pending = "Pending"
    Doing = "Doing"
    Done = "Done"
