# src/error_handler.py
from __future__ import annotations

from typing import Any, Dict, Optional
from flask import Blueprint, jsonify, current_app
from werkzeug.exceptions import HTTPException

errors_bp = Blueprint("errors", __name__)

# -----------------
# App exceptions
# -----------------
class AppError(Exception):
    status_code = 400
    code = "app_error"

    def __init__(self, message: str, *, code: Optional[str] = None, details: Any = None, status: Optional[int] = None):
        super().__init__(message)
        if code:
            self.code = code
        if status:
            self.status_code = status
        self.details = details


class ValidationError(AppError):
    status_code = 422
    code = "validation_error"


class UnauthorizedError(AppError):
    status_code = 401
    code = "unauthorized"


class ForbiddenError(AppError):
    status_code = 403
    code = "forbidden"


class NotFoundError(AppError):
    status_code = 404
    code = "not_found"


class ConflictError(AppError):
    status_code = 409
    code = "conflict"


# ------------- Handlers -------------

@errors_bp.app_errorhandler(AppError)
def handle_app_error(ex: AppError):
    current_app.logger.warning("AppError [%s]: %s", ex.code, ex)
    payload: Dict[str, Any] = {
        "success": False,
        "code": ex.code,
        "message": str(ex),
    }
    if ex.details is not None:
        payload["details"] = ex.details
    # Gợi ý: khi debug có thể thêm thông tin
    if current_app and current_app.debug:
        payload["debug"] = {"type": ex.__class__.__name__}
    return jsonify(payload), ex.status_code


@errors_bp.app_errorhandler(HTTPException)
def handle_http_error(ex: HTTPException):
    current_app.logger.warning("HTTPException: %s (%s)", ex.description, ex.code)
    payload = {
        "success": False,
        "code": "http_error",
        "message": ex.description or ex.name,
    }
    return jsonify(payload), ex.code or 500


@errors_bp.app_errorhandler(Exception)
def handle_unexpected(ex: Exception):
    current_app.logger.exception("Unexpected error: %s", ex)
    payload = {
        "success": False,
        "code": "internal_error",
        "message": "Internal Server Error",
    }
    # Khi debug, trả thêm detail để dễ sửa
    if current_app and current_app.debug:
        payload["debug"] = {"type": ex.__class__.__name__, "detail": str(ex)}
    return jsonify(payload), 500


# --- Map DomainError -> AppError ---
from src.domain.exceptions import DomainError, to_app_error

@errors_bp.app_errorhandler(DomainError)
def handle_domain_error(ex: DomainError):
    """
    Cho phép service raise DomainError và tự động ánh xạ sang AppError + HTTP code chuẩn.
    """
    app_ex = to_app_error(ex)        # Bảo đảm ra AppError/* cụ thể
    return handle_app_error(app_ex)  # Tái sử dụng handler chung
