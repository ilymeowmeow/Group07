# src/infrastructure/databases/db_base.py
from __future__ import annotations

from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base, sessionmaker
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session

Base = declarative_base()

_engine: Engine | None = None
_SessionLocal: sessionmaker | None = None


def init_engine(database_uri: str) -> Engine:
    global _engine, _SessionLocal
    if _engine is None:
        _engine = create_engine(
            database_uri,
            pool_pre_ping=True,
            future=True,
        )
        _SessionLocal = sessionmaker(bind=_engine, autocommit=False, autoflush=False, future=True)
    return _engine


def get_session() -> Session:
    if _SessionLocal is None:
        raise RuntimeError("Engine not initialized. Call init_engine() first.")
    return _SessionLocal()
