# src/infrastructure/models/__init__.py
from __future__ import annotations

# re-export Base để create_app import được
from ..databases import Base  # noqa: F401

# Import toàn bộ models để Base.metadata thấy hết
from .identity_models import *      # noqa: F401,F403
from .recruitment_models import *   # noqa: F401,F403
from .training_models import *      # noqa: F401,F403
from .work_models import *          # noqa: F401,F403
from .evaluation_models import *    # noqa: F401,F403

__all__ = ["Base"]
