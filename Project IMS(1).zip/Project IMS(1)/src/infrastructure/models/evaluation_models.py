from sqlalchemy import Integer, ForeignKey, CheckConstraint
from sqlalchemy.orm import Mapped, mapped_column
from ..databases.db_base import Base

class Evaluation(Base):
    __tablename__ = "evaluations"
    evalID: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    internID: Mapped[int] = mapped_column(Integer, ForeignKey("intern_profiles.internID"), nullable=False)
    score: Mapped[int] = mapped_column(Integer, nullable=False)

    __table_args__ = (
        CheckConstraint("score >= 0 AND score <= 100", name="ck_evaluation_score_range"),
    )
