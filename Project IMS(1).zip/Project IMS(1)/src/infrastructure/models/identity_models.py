from sqlalchemy import Integer, String, ForeignKey, CheckConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship
from ..databases.db_base import Base
from ...enums import Role

class User(Base):
    __tablename__ = "users"
    userID: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    email: Mapped[str] = mapped_column(String(255), nullable=False, unique=True, index=True)
    role: Mapped[str] = mapped_column(String(32), nullable=False)

    __table_args__ = (
        CheckConstraint(
            f"role in ('{Role.Admin.value}','{Role.HR.value}','{Role.Coordinator.value}','{Role.Mentor.value}','{Role.Intern.value}')",
            name="ck_users_role"
        ),
    )

    intern_profile = relationship("InternProfile", back_populates="user", uselist=False)

class InternProfile(Base):
    __tablename__ = "intern_profiles"
    internID: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    userID: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("users.userID"),  # NO ACTION mặc định của SQL Server sẽ chặn xóa khi còn tham chiếu
        unique=True,
        nullable=False
    )
    skill: Mapped[str] = mapped_column(String(255), nullable=True)

    user = relationship("User", back_populates="intern_profile")
