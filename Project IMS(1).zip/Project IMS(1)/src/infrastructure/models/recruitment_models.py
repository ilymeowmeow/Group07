from sqlalchemy import Integer, String, ForeignKey, CheckConstraint, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship
from ..databases.db_base import Base
from ...enums import CampaignStatus, ApplicationStatus

class RecruitmentCampaign(Base):
    __tablename__ = "campaigns"
    campID: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    title: Mapped[str] = mapped_column(String(200), nullable=False)
    status: Mapped[str] = mapped_column(String(16), nullable=False, default=CampaignStatus.Open.value)

    __table_args__ = (
        CheckConstraint(
            f"status in ('{CampaignStatus.Open.value}','{CampaignStatus.Closed.value}')",
            name="ck_campaign_status"
        ),
    )

    applications = relationship("Application", back_populates="campaign")

class Application(Base):
    __tablename__ = "applications"
    appID: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    campID: Mapped[int] = mapped_column(Integer, ForeignKey("campaigns.campID"), nullable=False)
    userID: Mapped[int] = mapped_column(Integer, ForeignKey("users.userID"), nullable=False)
    status: Mapped[str] = mapped_column(String(16), nullable=False, default=ApplicationStatus.Pending.value)

    __table_args__ = (
        UniqueConstraint("campID", "userID", name="uq_app_camp_user"),
        CheckConstraint(
            f"status in ('{ApplicationStatus.Pending.value}','{ApplicationStatus.Approved.value}','{ApplicationStatus.Rejected.value}')",
            name="ck_application_status"
        ),
    )

    campaign = relationship("RecruitmentCampaign", back_populates="applications")
