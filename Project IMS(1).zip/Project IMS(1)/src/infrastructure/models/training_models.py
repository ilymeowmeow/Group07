from sqlalchemy import Integer, String, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship
from ..databases.db_base import Base

class TrainingProgram(Base):
    __tablename__ = "training_programs"
    progID: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    title: Mapped[str] = mapped_column(String(200), nullable=False)
    goal: Mapped[str] = mapped_column(String(500), nullable=True)

    projects = relationship("Project", back_populates="program")

class Project(Base):
    __tablename__ = "projects"
    projID: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    progID: Mapped[int] = mapped_column(Integer, ForeignKey("training_programs.progID"), nullable=False)
    title: Mapped[str] = mapped_column(String(200), nullable=False)

    program = relationship("TrainingProgram", back_populates="projects")
