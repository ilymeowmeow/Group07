from sqlalchemy import Integer, String, ForeignKey, CheckConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship
from ..databases.db_base import Base
from ...enums import AssignmentStatus

class Assignment(Base):
    __tablename__ = "assignments"
    assignID: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    projID: Mapped[int] = mapped_column(Integer, ForeignKey("projects.projID"), nullable=False)
    internID: Mapped[int] = mapped_column(Integer, ForeignKey("intern_profiles.internID"), nullable=False)
    status: Mapped[str] = mapped_column(String(16), nullable=False, default=AssignmentStatus.Pending.value)

    __table_args__ = (
        CheckConstraint(
            f"status in ('{AssignmentStatus.Pending.value}','{AssignmentStatus.Doing.value}','{AssignmentStatus.Done.value}')",
            name="ck_assignment_status"
        ),
    )

    # (relationships tùy nhu cầu; để tối thiểu có thể bỏ qua)
