# src/infrastructure/repositories/__init__.py
from .identity_repository import UserRepository, InternRepository
from .recruitment_repository import RecruitmentCampaignRepository, ApplicationRepository
from .training_repository import ProgramRepository, ProjectRepository
from .work_repository import AssignmentRepository
from .evaluation_repository import EvaluationRepository

__all__ = [
    "UserRepository", "InternRepository",
    "RecruitmentCampaignRepository", "ApplicationRepository",
    "ProgramRepository", "ProjectRepository",
    "AssignmentRepository",
    "EvaluationRepository",
]
