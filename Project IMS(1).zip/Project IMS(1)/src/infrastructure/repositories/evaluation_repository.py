# src/infrastructure/repositories/evaluation_repository.py
from __future__ import annotations
from typing import List, Tuple, Optional

from sqlalchemy.orm import Session
from sqlalchemy import func

# ORM
from ..models.evaluation_models import Evaluation as EvalORM
from ..models.identity_models import InternProfile as InternORM

# Domain
from ...domain.models.evaluation import Evaluation as DEval
from ...domain.exceptions import NotFoundError, ValidationError


# ---------- Mapper ----------
def _to_domain_eval(o: EvalORM) -> DEval:
    return DEval(evalID=o.evalID, internID=o.internID, score=o.score)


class EvaluationRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def get(self, eval_id: int) -> DEval:
        obj = self.db.get(EvalORM, eval_id)
        if not obj:
            raise NotFoundError("evaluation not found", details={"evalID": eval_id})
        return _to_domain_eval(obj)

    def list_by_intern(self, intern_id: int, *, limit: int = 50, offset: int = 0) -> Tuple[List[DEval], int]:
        q = self.db.query(EvalORM).filter(EvalORM.internID == intern_id)
        total = q.count()
        items = (
            q.order_by(EvalORM.evalID.asc())
             .offset(offset).limit(limit).all()
        )
        return [ _to_domain_eval(x) for x in items ], total

    def create(self, data: DEval) -> DEval:
        # FK check
        if not self.db.get(InternORM, data.internID):
            raise ValidationError("invalid internID", details={"internID": data.internID})
        obj = EvalORM(internID=data.internID, score=data.score)
        self.db.add(obj)
        self.db.flush()
        return _to_domain_eval(obj)

    def update(self, eval_id: int, *, score: Optional[int] = None) -> DEval:
        obj = self.db.get(EvalORM, eval_id)
        if not obj:
            raise NotFoundError("evaluation not found", details={"evalID": eval_id})
        if score is not None:
            obj.score = score
        self.db.flush()
        return _to_domain_eval(obj)

    def delete(self, eval_id: int) -> None:
        obj = self.db.get(EvalORM, eval_id)
        if not obj:
            raise NotFoundError("evaluation not found", details={"evalID": eval_id})
        self.db.delete(obj)
        self.db.flush()

    def avg_score(self, intern_id: int) -> Optional[float]:
        q = self.db.query(func.avg(EvalORM.score)).filter(EvalORM.internID == intern_id)
        val = q.scalar()
        # Trả None nếu chưa có dữ liệu (như spec)
        return float(val) if val is not None else None
