# src/infrastructure/repositories/identity_repository.py
from __future__ import annotations
from typing import Optional, List, Tuple

from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError, NoResultFound

# ORM
from ..models.identity_models import User as UserORM, InternProfile as InternORM

# Domain
from ...domain.models.user import User as DUser
from ...domain.models.intern import InternProfile as DIntern
from ...domain.exceptions import (
    NotFoundError, ConflictError, ValidationError
)


# ---------- Mappers ----------
def _to_domain_user(o: UserORM) -> DUser:
    return DUser(userID=o.userID, name=o.name, email=o.email, role=o.role)

def _to_domain_intern(o: InternORM) -> DIntern:
    return DIntern(internID=o.internID, userID=o.userID, skill=o.skill)


# ---------- User ----------
class UserRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def get(self, user_id: int) -> DUser:
        obj = self.db.get(UserORM, user_id)
        if not obj:
            raise NotFoundError("user not found", details={"userID": user_id})
        return _to_domain_user(obj)

    def get_by_email(self, email: str) -> Optional[DUser]:
        obj = self.db.query(UserORM).filter(UserORM.email == email).first()
        return _to_domain_user(obj) if obj else None

    def list(self, *, role: Optional[str] = None, limit: int = 50, offset: int = 0) -> Tuple[List[DUser], int]:
        q = self.db.query(UserORM)
        if role:
            q = q.filter(UserORM.role == role)
        total = q.count()
        items = (
            q.order_by(UserORM.userID.asc())
             .offset(offset).limit(limit).all()
        )
        return [ _to_domain_user(x) for x in items ], total

    def create(self, data: DUser) -> DUser:
        # email unique do DB enforce; để IntegrityError -> conflict
        obj = UserORM(name=data.name, email=data.email, role=data.role)
        self.db.add(obj)
        try:
            self.db.flush()
        except IntegrityError as ex:
            raise ConflictError("email already exists", details={"email": data.email}) from ex
        return _to_domain_user(obj)

    def update(self, user_id: int, **fields) -> DUser:
        obj = self.db.get(UserORM, user_id)
        if not obj:
            raise NotFoundError("user not found", details={"userID": user_id})
        for k in ("name", "email", "role"):
            if k in fields and fields[k] is not None:
                setattr(obj, k, fields[k])
        try:
            self.db.flush()
        except IntegrityError as ex:
            raise ConflictError("email already exists", details={"email": fields.get("email")}) from ex
        return _to_domain_user(obj)

    def delete(self, user_id: int) -> None:
        obj = self.db.get(UserORM, user_id)
        if not obj:
            raise NotFoundError("user not found", details={"userID": user_id})
        self.db.delete(obj)
        try:
            self.db.flush()
        except IntegrityError as ex:
            # still referenced by Application or InternProfile
            raise ConflictError("user is still referenced, cannot delete", details={"userID": user_id}) from ex


# ---------- InternProfile ----------
class InternRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def get(self, intern_id: int) -> DIntern:
        obj = self.db.get(InternORM, intern_id)
        if not obj:
            raise NotFoundError("intern profile not found", details={"internID": intern_id})
        return _to_domain_intern(obj)

    def get_by_user(self, user_id: int) -> Optional[DIntern]:
        obj = self.db.query(InternORM).filter(InternORM.userID == user_id).first()
        return _to_domain_intern(obj) if obj else None

    def list(self, *, user_id: Optional[int] = None, limit: int = 50, offset: int = 0) -> Tuple[List[DIntern], int]:
        q = self.db.query(InternORM)
        if user_id:
            q = q.filter(InternORM.userID == user_id)
        total = q.count()
        items = (
            q.order_by(InternORM.internID.asc())
             .offset(offset).limit(limit).all()
        )
        return [ _to_domain_intern(x) for x in items ], total

    def create(self, data: DIntern) -> DIntern:
        obj = InternORM(userID=data.userID, skill=data.skill)
        self.db.add(obj)
        try:
            self.db.flush()
        except IntegrityError as ex:
            # unique 1-1 userID or FK violation
            raise ConflictError("intern profile conflict (unique or FK)", details={"userID": data.userID}) from ex
        return _to_domain_intern(obj)

    def update(self, intern_id: int, *, skill: Optional[str] = None) -> DIntern:
        obj = self.db.get(InternORM, intern_id)
        if not obj:
            raise NotFoundError("intern profile not found", details={"internID": intern_id})
        if skill is not None:
            obj.skill = skill
        self.db.flush()
        return _to_domain_intern(obj)

    def delete(self, intern_id: int) -> None:
        obj = self.db.get(InternORM, intern_id)
        if not obj:
            raise NotFoundError("intern profile not found", details={"internID": intern_id})
        self.db.delete(obj)
        try:
            self.db.flush()
        except IntegrityError as ex:
            # referenced by Assignment/Evaluation
            raise ConflictError("intern profile is referenced, cannot delete", details={"internID": intern_id}) from ex
