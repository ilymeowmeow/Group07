# src/infrastructure/repositories/recruitment_repository.py
from __future__ import annotations
from typing import Optional, List, Tuple

from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError

# ORM
from ..models.recruitment_models import RecruitmentCampaign as CampORM, Application as AppORM

# Domain
from ...domain.models.recruitment import RecruitmentCampaign as DCampaign
from ...domain.models.application import Application as DApp
from ...domain.exceptions import (
    NotFoundError, ConflictError, ValidationError,
)

# Enums
from ...enums import CampaignStatus, ApplicationStatus


# ---------- Mappers ----------
def _to_domain_campaign(o: CampORM) -> DCampaign:
    return DCampaign(campID=o.campID, title=o.title, status=o.status)

def _to_domain_app(o: AppORM) -> DApp:
    return DApp(appID=o.appID, campID=o.campID, userID=o.userID, status=o.status)


# ---------- RecruitmentCampaign ----------
class RecruitmentCampaignRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def get(self, camp_id: int) -> DCampaign:
        obj = self.db.get(CampORM, camp_id)
        if not obj:
            raise NotFoundError("campaign not found", details={"campID": camp_id})
        return _to_domain_campaign(obj)

    def list(self, *, status: Optional[str] = None, limit: int = 50, offset: int = 0) -> Tuple[List[DCampaign], int]:
        q = self.db.query(CampORM)
        if status:
            q = q.filter(CampORM.status == status)
        total = q.count()
        items = (
            q.order_by(CampORM.campID.asc())
             .offset(offset).limit(limit).all()
        )
        return [_to_domain_campaign(x) for x in items], total

    def create(self, data: DCampaign) -> DCampaign:
        obj = CampORM(title=data.title, status=data.status or CampaignStatus.Open.value)
        self.db.add(obj)
        self.db.flush()
        return _to_domain_campaign(obj)

    def update(self, camp_id: int, **fields) -> DCampaign:
        obj = self.db.get(CampORM, camp_id)
        if not obj:
            raise NotFoundError("campaign not found", details={"campID": camp_id})
        for k in ("title", "status"):
            if k in fields and fields[k] is not None:
                setattr(obj, k, fields[k])
        self.db.flush()
        return _to_domain_campaign(obj)

    def close(self, camp_id: int) -> DCampaign:
        obj = self.db.get(CampORM, camp_id)
        if not obj:
            raise NotFoundError("campaign not found", details={"campID": camp_id})
        if obj.status == CampaignStatus.Closed.value:
            raise ConflictError("campaign already closed", details={"campID": camp_id})
        obj.status = CampaignStatus.Closed.value
        self.db.flush()
        return _to_domain_campaign(obj)

    def delete(self, camp_id: int) -> None:
        obj = self.db.get(CampORM, camp_id)
        if not obj:
            raise NotFoundError("campaign not found", details={"campID": camp_id})
        # Không xóa nếu còn Application
        has_apps = self.db.query(AppORM).filter(AppORM.campID == camp_id).limit(1).first() is not None
        if has_apps:
            raise ConflictError("cannot delete campaign with applications", details={"campID": camp_id})
        self.db.delete(obj)
        self.db.flush()


# ---------- Application ----------
class ApplicationRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def get(self, app_id: int) -> DApp:
        obj = self.db.get(AppORM, app_id)
        if not obj:
            raise NotFoundError("application not found", details={"appID": app_id})
        return _to_domain_app(obj)

    def list(self, *, camp_id: Optional[int] = None, status: Optional[str] = None,
             limit: int = 50, offset: int = 0) -> Tuple[List[DApp], int]:
        q = self.db.query(AppORM)
        if camp_id:
            q = q.filter(AppORM.campID == camp_id)
        if status:
            q = q.filter(AppORM.status == status)
        total = q.count()
        items = (
            q.order_by(AppORM.appID.asc())
             .offset(offset).limit(limit).all()
        )
        return [_to_domain_app(x) for x in items], total

    def create(self, data: DApp) -> DApp:
        # Campaign phải Open
        camp = self.db.get(CampORM, data.campID)
        if not camp:
            raise NotFoundError("campaign not found", details={"campID": data.campID})
        if camp.status != CampaignStatus.Open.value:
            raise ValidationError("campaign is closed", details={"campID": data.campID})

        obj = AppORM(campID=data.campID, userID=data.userID, status=ApplicationStatus.Pending.value)
        self.db.add(obj)
        try:
            self.db.flush()
        except IntegrityError as ex:
            # UNIQUE(campID,userID)
            raise ConflictError("duplicate application for (campID,userID)",
                                details={"campID": data.campID, "userID": data.userID}) from ex
        return _to_domain_app(obj)

    # ---- tiện ích bổ sung cho services: apply(camp_id, user_id) ----
    def apply(self, *, camp_id: int, user_id: int) -> DApp:
        data = DApp(appID=None, campID=camp_id, userID=user_id, status=ApplicationStatus.Pending.value)
        return self.create(data)

    def approve(self, app_id: int) -> DApp:
        obj = self.db.get(AppORM, app_id)
        if not obj:
            raise NotFoundError("application not found", details={"appID": app_id})
        if obj.status != ApplicationStatus.Pending.value:
            raise ConflictError("can only approve from Pending", details={"status": obj.status})
        obj.status = ApplicationStatus.Approved.value
        self.db.flush()
        return _to_domain_app(obj)

    def reject(self, app_id: int) -> DApp:
        obj = self.db.get(AppORM, app_id)
        if not obj:
            raise NotFoundError("application not found", details={"appID": app_id})
        if obj.status != ApplicationStatus.Pending.value:
            raise ConflictError("can only reject from Pending", details={"status": obj.status})
        obj.status = ApplicationStatus.Rejected.value
        self.db.flush()
        return _to_domain_app(obj)

    def delete(self, app_id: int) -> None:
        obj = self.db.get(AppORM, app_id)
        if not obj:
            raise NotFoundError("application not found", details={"appID": app_id})
        if obj.status != ApplicationStatus.Pending.value:
            raise ConflictError("can only delete when Pending", details={"status": obj.status})
        self.db.delete(obj)
        self.db.flush()


# ---- Alias để không phải đổi ở services (compat) ----
CampaignRepository = RecruitmentCampaignRepository

__all__ = ["CampaignRepository", "RecruitmentCampaignRepository", "ApplicationRepository"]
