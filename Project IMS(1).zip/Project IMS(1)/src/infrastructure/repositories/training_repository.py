# src/infrastructure/repositories/training_repository.py
from __future__ import annotations
from typing import Optional, List, Tuple

from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError

# ORM
from ..models.training_models import TrainingProgram as ProgramORM, Project as ProjectORM
from ..models.work_models import Assignment as AssignmentORM

# Domain
from ...domain.models.training import TrainingProgram as DProgram
from ...domain.models.project import Project as DProject
from ...domain.exceptions import NotFoundError, ConflictError


# ---------- Mappers ----------
def _to_domain_program(o: ProgramORM) -> DProgram:
    return DProgram(progID=o.progID, title=o.title, goal=o.goal)

def _to_domain_project(o: ProjectORM) -> DProject:
    return DProject(projID=o.projID, progID=o.progID, title=o.title)


# ---------- Program ----------
class ProgramRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def get(self, prog_id: int) -> DProgram:
        obj = self.db.get(ProgramORM, prog_id)
        if not obj:
            raise NotFoundError("program not found", details={"progID": prog_id})
        return _to_domain_program(obj)

    def list(self, *, limit: int = 50, offset: int = 0) -> Tuple[List[DProgram], int]:
        q = self.db.query(ProgramORM)
        total = q.count()
        items = (
            q.order_by(ProgramORM.progID.asc())
             .offset(offset).limit(limit).all()
        )
        return [ _to_domain_program(x) for x in items ], total

    def create(self, data: DProgram) -> DProgram:
        obj = ProgramORM(title=data.title, goal=data.goal or "")
        self.db.add(obj)
        self.db.flush()
        return _to_domain_program(obj)

    def update(self, prog_id: int, **fields) -> DProgram:
        obj = self.db.get(ProgramORM, prog_id)
        if not obj:
            raise NotFoundError("program not found", details={"progID": prog_id})
        for k in ("title", "goal"):
            if k in fields and fields[k] is not None:
                setattr(obj, k, fields[k])
        self.db.flush()
        return _to_domain_program(obj)

    def delete(self, prog_id: int) -> None:
        obj = self.db.get(ProgramORM, prog_id)
        if not obj:
            raise NotFoundError("program not found", details={"progID": prog_id})
        # Không xóa nếu còn Project
        has_proj = self.db.query(ProjectORM).filter(ProjectORM.progID == prog_id).limit(1).first() is not None
        if has_proj:
            raise ConflictError("cannot delete program with projects", details={"progID": prog_id})
        self.db.delete(obj)
        self.db.flush()


# ---------- Project ----------
class ProjectRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def get(self, proj_id: int) -> DProject:
        obj = self.db.get(ProjectORM, proj_id)
        if not obj:
            raise NotFoundError("project not found", details={"projID": proj_id})
        return _to_domain_project(obj)

    def list_by_program(self, prog_id: int, *, limit: int = 50, offset: int = 0) -> Tuple[List[DProject], int]:
        q = self.db.query(ProjectORM).filter(ProjectORM.progID == prog_id)
        total = q.count()
        items = (
            q.order_by(ProjectORM.projID.asc())
             .offset(offset).limit(limit).all()
        )
        return [ _to_domain_project(x) for x in items ], total

    def create(self, data: DProject) -> DProject:
        # FK progID do DB enforce
        obj = ProjectORM(progID=data.progID, title=data.title)
        self.db.add(obj)
        try:
            self.db.flush()
        except IntegrityError as ex:
            raise ConflictError("invalid progID or duplicate", details={"progID": data.progID}) from ex
        return _to_domain_project(obj)

    def delete(self, proj_id: int) -> None:
        obj = self.db.get(ProjectORM, proj_id)
        if not obj:
            raise NotFoundError("project not found", details={"projID": proj_id})
        # Không xóa nếu còn Assignment
        has_assign = self.db.query(AssignmentORM).filter(AssignmentORM.projID == proj_id).limit(1).first() is not None
        if has_assign:
            raise ConflictError("cannot delete project with assignments", details={"projID": proj_id})
        self.db.delete(obj)
        self.db.flush()
