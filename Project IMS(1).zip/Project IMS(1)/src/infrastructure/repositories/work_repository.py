# src/infrastructure/repositories/work_repository.py
from __future__ import annotations
from typing import Optional, List, Tuple

from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError

# ORM
from ..models.work_models import Assignment as AssignORM
from ..models.training_models import Project as ProjectORM
from ..models.identity_models import InternProfile as InternORM

# Domain
from ...domain.models.assignment import Assignment as DAssign
from ...domain.exceptions import NotFoundError, ConflictError, ValidationError

# Enum
from ...enums import AssignmentStatus


# ---------- Mapper ----------
def _to_domain_assign(o: AssignORM) -> DAssign:
    return DAssign(assignID=o.assignID, projID=o.projID, internID=o.internID, status=o.status)


class AssignmentRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def get(self, assign_id: int) -> DAssign:
        obj = self.db.get(AssignORM, assign_id)
        if not obj:
            raise NotFoundError("assignment not found", details={"assignID": assign_id})
        return _to_domain_assign(obj)

    def list_by_project(self, proj_id: int, *, limit: int = 50, offset: int = 0) -> Tuple[List[DAssign], int]:
        q = self.db.query(AssignORM).filter(AssignORM.projID == proj_id)
        total = q.count()
        items = (
            q.order_by(AssignORM.assignID.asc())
             .offset(offset).limit(limit).all()
        )
        return [ _to_domain_assign(x) for x in items ], total

    def list_by_intern(self, intern_id: int, *, limit: int = 50, offset: int = 0) -> Tuple[List[DAssign], int]:
        q = self.db.query(AssignORM).filter(AssignORM.internID == intern_id)
        total = q.count()
        items = (
            q.order_by(AssignORM.assignID.asc())
             .offset(offset).limit(limit).all()
        )
        return [ _to_domain_assign(x) for x in items ], total

    def create(self, data: DAssign) -> DAssign:
        # FK check: projID, internID tồn tại
        if not self.db.get(ProjectORM, data.projID):
            raise ValidationError("invalid projID", details={"projID": data.projID})
        if not self.db.get(InternORM, data.internID):
            raise ValidationError("invalid internID", details={"internID": data.internID})
        obj = AssignORM(projID=data.projID, internID=data.internID, status=AssignmentStatus.Pending.value)
        self.db.add(obj)
        self.db.flush()
        return _to_domain_assign(obj)

    def update_status(self, assign_id: int, new_status: str) -> DAssign:
        obj = self.db.get(AssignORM, assign_id)
        if not obj:
            raise NotFoundError("assignment not found", details={"assignID": assign_id})

        # Transition: Pending -> Doing -> Done
        if obj.status == AssignmentStatus.Pending.value and new_status == AssignmentStatus.Doing.value:
            obj.status = new_status
        elif obj.status == AssignmentStatus.Doing.value and new_status == AssignmentStatus.Done.value:
            obj.status = new_status
        else:
            raise ConflictError("invalid status transition",
                                      details={"from": obj.status, "to": new_status})
        self.db.flush()
        return _to_domain_assign(obj)

    def delete(self, assign_id: int) -> None:
        obj = self.db.get(AssignORM, assign_id)
        if not obj:
            raise NotFoundError("assignment not found", details={"assignID": assign_id})
        if obj.status == AssignmentStatus.Done.value:
            raise ConflictError("cannot delete a Done assignment", details={"assignID": assign_id})
        self.db.delete(obj)
        self.db.flush()
