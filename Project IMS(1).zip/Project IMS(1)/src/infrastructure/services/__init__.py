# src/infrastructure/services/__init__.py
from __future__ import annotations

from typing import Mapping, Any, Optional, Union

from .email_service import (
    BaseEmailService,
    ConsoleEmailService,
    SMTPEmailService,
)

ConfigLike = Union[Mapping[str, Any], "Flask"]  # type: ignore[name-defined]


def _get_cfg(cfg: ConfigLike) -> Mapping[str, Any]:
    """Trích dict config từ Flask app hoặc từ mapping thuần."""
    try:
        # Flask app
        from flask import Flask  # local import để tránh hard dep khi chạy script thuần

        if isinstance(cfg, Flask):
            return cfg.config  # type: ignore[return-value]
    except Exception:
        pass
    # mapping thuần
    return cfg  # type: ignore[return-value]


def build_email_service(cfg: ConfigLike) -> BaseEmailService:
    """
    Factory tạo EmailService từ config/app.
    Ưu tiên các key:
      EMAIL_BACKEND: 'console' (mặc định) | 'smtp'
      EMAIL_FROM
      EMAIL_HOST, EMAIL_PORT, EMAIL_USERNAME, EMAIL_PASSWORD
      EMAIL_USE_TLS (bool), EMAIL_USE_SSL (bool)
    """
    c = _get_cfg(cfg)

    backend = str(c.get("EMAIL_BACKEND", "console")).lower()
    default_from = c.get("EMAIL_FROM") or c.get("MAIL_FROM") or "no-reply@localhost"

    if backend == "smtp":
        host = c.get("EMAIL_HOST") or c.get("MAIL_SERVER")
        port = c.get("EMAIL_PORT") or c.get("MAIL_PORT") or 587
        username = c.get("EMAIL_USERNAME") or c.get("MAIL_USERNAME")
        password = c.get("EMAIL_PASSWORD") or c.get("MAIL_PASSWORD")
        use_tls = bool(c.get("EMAIL_USE_TLS", True))
        use_ssl = bool(c.get("EMAIL_USE_SSL", False))

        return SMTPEmailService(
            host=str(host),
            port=int(port),
            username=username if username else None,
            password=password if password else None,
            use_tls=use_tls,
            use_ssl=use_ssl,
            default_sender=str(default_from),
        )

    # Mặc định: console (ghi log)
    return ConsoleEmailService(default_sender=str(default_from))


__all__ = [
    "BaseEmailService",
    "ConsoleEmailService",
    "SMTPEmailService",
    "build_email_service",
]
