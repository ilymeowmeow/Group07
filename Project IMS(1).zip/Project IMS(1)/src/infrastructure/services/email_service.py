# src/infrastructure/services/email_service.py
from __future__ import annotations

import logging
import smtplib
from email.message import EmailMessage
from typing import Iterable, Optional, Sequence


logger = logging.getLogger("ims.email")


class BaseEmailService:
    """Interface cơ bản cho email service."""

    def __init__(self, default_sender: str = "no-reply@localhost") -> None:
        self.default_sender = default_sender

    def send(
        self,
        to: Sequence[str] | str,
        subject: str,
        body: str,
        *,
        html: bool = False,
        cc: Optional[Sequence[str]] = None,
        bcc: Optional[Sequence[str]] = None,
        sender: Optional[str] = None,
        attachments: Optional[Iterable[tuple[str, bytes, str]]] = None,
    ) -> str:
        """
        Gửi email.
        attachments: iterable các tuple (filename, content_bytes, mime_type)
        Trả về message-id (nếu có) hoặc chuỗi mô tả.
        """
        raise NotImplementedError


class ConsoleEmailService(BaseEmailService):
    """Ghi email vào log – phù hợp môi trường dev/test."""

    def send(
        self,
        to: Sequence[str] | str,
        subject: str,
        body: str,
        *,
        html: bool = False,
        cc: Optional[Sequence[str]] = None,
        bcc: Optional[Sequence[str]] = None,
        sender: Optional[str] = None,
        attachments: Optional[Iterable[tuple[str, bytes, str]]] = None,
    ) -> str:
        _to = [to] if isinstance(to, str) else list(to)
        _cc = [] if cc is None else list(cc)
        _bcc = [] if bcc is None else list(bcc)
        logger.info(
            "[EMAIL][console]\nFrom: %s\nTo: %s\nCc: %s\nBcc: %s\nSubject: %s\nHTML: %s\nBody:\n%s\nAttachments: %s",
            sender or self.default_sender,
            _to,
            _cc,
            _bcc,
            subject,
            html,
            body,
            [a[0] for a in attachments] if attachments else [],
        )
        # Trả về id giả để upstream có thể log
        return "console-message"


class SMTPEmailService(BaseEmailService):
    """Gửi qua SMTP chuẩn (smtplib)."""

    def __init__(
        self,
        *,
        host: str,
        port: int = 587,
        username: Optional[str] = None,
        password: Optional[str] = None,
        use_tls: bool = True,
        use_ssl: bool = False,
        default_sender: str = "no-reply@localhost",
        timeout: int = 30,
    ) -> None:
        super().__init__(default_sender=default_sender)
        self.host = host
        self.port = port
        self.username = username
        self.password = password
        self.use_tls = use_tls
        self.use_ssl = use_ssl
        self.timeout = timeout

    def _open(self) -> smtplib.SMTP:
        if self.use_ssl:
            smtp = smtplib.SMTP_SSL(self.host, self.port, timeout=self.timeout)
        else:
            smtp = smtplib.SMTP(self.host, self.port, timeout=self.timeout)
            if self.use_tls:
                smtp.starttls()
        if self.username:
            smtp.login(self.username, self.password or "")
        return smtp

    def send(
        self,
        to: Sequence[str] | str,
        subject: str,
        body: str,
        *,
        html: bool = False,
        cc: Optional[Sequence[str]] = None,
        bcc: Optional[Sequence[str]] = None,
        sender: Optional[str] = None,
        attachments: Optional[Iterable[tuple[str, bytes, str]]] = None,
    ) -> str:
        recipients = [to] if isinstance(to, str) else list(to)
        cc_list = [] if cc is None else list(cc)
        bcc_list = [] if bcc is None else list(bcc)
        all_rcpt = list(dict.fromkeys(recipients + cc_list + bcc_list))  # unique, giữ thứ tự

        msg = EmailMessage()
        msg["From"] = sender or self.default_sender
        msg["To"] = ", ".join(recipients)
        if cc_list:
            msg["Cc"] = ", ".join(cc_list)
        msg["Subject"] = subject

        if html:
            msg.set_content("This is an HTML email. Please use an HTML-capable client.")
            msg.add_alternative(body, subtype="html")
        else:
            msg.set_content(body)

        # Đính kèm
        if attachments:
            for filename, content, mime in attachments:
                maintype, _, subtype = mime.partition("/")
                if not subtype:
                    maintype, subtype = "application", "octet-stream"
                msg.add_attachment(content, maintype=maintype, subtype=subtype, filename=filename)

        try:
            with self._open() as smtp:
                resp = smtp.send_message(msg, from_addr=msg["From"], to_addrs=all_rcpt)
                # send_message trả dict lỗi; nếu rỗng coi như thành công
                if resp:
                    logger.warning("SMTP partial errors: %s", resp)
            # message-id do smtplib không tự trả; dùng header tự tạo hoặc lấy từ EmailMessage
            msg_id = msg.get("Message-Id") or "smtp-message"
            logger.info("[EMAIL][smtp] sent to %s, subject=%s", all_rcpt, subject)
            return msg_id
        except Exception as ex:
            logger.exception("SMTP send failed: %s", ex)
            raise
