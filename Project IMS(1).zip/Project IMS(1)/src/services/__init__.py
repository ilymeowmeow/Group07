# src/services/__init__.py
from __future__ import annotations

from .identity_service import IdentityService
from .recruitment_service import RecruitmentService
from .training_service import TrainingService
from .work_service import WorkService
from .evaluation_service import EvaluationService

__all__ = [
    "IdentityService",
    "RecruitmentService",
    "TrainingService",
    "WorkService",
    "EvaluationService",
]
