# src/services/evaluation_service.py
from __future__ import annotations

from typing import Callable, Iterable
from sqlalchemy.exc import IntegrityError

from src.infrastructure.repositories.evaluation_repository import EvaluationRepository
from src.infrastructure.repositories.identity_repository import InternRepository
from src.domain.exceptions import ValidationError, NotFoundError


class EvaluationService:
    """
    Evaluation + tiện ích avg
    """

    def __init__(self, db_provider: Callable):
        self._db = db_provider

    def create(self, *, intern_id: int, score: int, note: str | None = None):
        db = self._db()
        interns = InternRepository(db)
        evals = EvaluationRepository(db)

        if not interns.get(intern_id):
            raise ValidationError("internID invalid")
        if score is None or not (0 <= int(score) <= 100):
            raise ValidationError("score must be in [0,100]")

        try:
            return evals.create(intern_id=intern_id, score=int(score), note=note)
        except IntegrityError as ex:
            raise ValidationError(f"Cannot create evaluation: {ex.orig}")  # pragma: no cover

    def get(self, eval_id: int):
        db = self._db()
        evals = EvaluationRepository(db)
        e = evals.get(eval_id)
        if not e:
            raise NotFoundError("Evaluation not found")
        return e

    def update(self, eval_id: int, *, score: int | None = None, note: str | None = None):
        db = self._db()
        evals = EvaluationRepository(db)
        e = evals.get(eval_id)
        if not e:
            raise NotFoundError("Evaluation not found")
        if score is not None and not (0 <= int(score) <= 100):
            raise ValidationError("score must be in [0,100]")
        return evals.update(eval_id, score=None if score is None else int(score), note=note)

    def delete(self, eval_id: int):
        db = self._db()
        evals = EvaluationRepository(db)
        e = evals.get(eval_id)
        if not e:
            raise NotFoundError("Evaluation not found")
        evals.delete(eval_id)

    def list_by_intern(self, intern_id: int, limit: int = 50, offset: int = 0) -> Iterable:
        db = self._db()
        evals = EvaluationRepository(db)
        return evals.list_by_intern(intern_id, limit=limit, offset=offset)

    def avg_score(self, intern_id: int) -> float | None:
        db = self._db()
        evals = EvaluationRepository(db)
        return evals.avg_score(intern_id)
