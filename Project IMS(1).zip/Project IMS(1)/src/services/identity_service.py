# src/services/identity_service.py
from __future__ import annotations

from typing import Callable, Iterable, Optional
from sqlalchemy.exc import IntegrityError

from src.infrastructure.repositories.identity_repository import (
    UserRepository,
    InternRepository,
)
from src.domain.exceptions import ValidationError, ConflictError, NotFoundError


class IdentityService:
    """
    User + InternProfile
    """

    def __init__(self, db_provider: Callable):
        self._db = db_provider

    # ---------- User ----------

    def create_user(self, *, name: str, email: str, role: str):
        db = self._db()
        repo = UserRepository(db)

        if not email:
            raise ValidationError("email is required")
        if repo.get_by_email(email):
            raise ConflictError("Email already exists")

        try:
            return repo.create(name=name, email=email, role=role)
        except IntegrityError as ex:
            raise ConflictError(f"Cannot create user: {ex.orig}")  # pragma: no cover

    def get_user(self, user_id: int):
        db = self._db()
        repo = UserRepository(db)
        u = repo.get(user_id)
        if not u:
            raise NotFoundError("User not found")
        return u

    def list_users(self, *, role: Optional[str] = None) -> Iterable:
        db = self._db()
        repo = UserRepository(db)
        return repo.list(role=role)

    def update_user(self, user_id: int, *, name: Optional[str] = None, email: Optional[str] = None, role: Optional[str] = None):
        db = self._db()
        repo = UserRepository(db)
        u = repo.get(user_id)
        if not u:
            raise NotFoundError("User not found")

        if email:
            # email phải unique
            other = repo.get_by_email(email)
            if other and other.userID != user_id:
                raise ConflictError("Email already exists")

        return repo.update(user_id, name=name, email=email, role=role)

    def delete_user(self, user_id: int):
        db = self._db()
        repo = UserRepository(db)
        u = repo.get(user_id)
        if not u:
            raise NotFoundError("User not found")
        try:
            repo.delete(user_id)
        except IntegrityError:
            # còn tham chiếu (Application, InternProfile, …)
            raise ConflictError("User is referenced by other records, cannot delete")

    # ---------- InternProfile ----------

    def create_intern_profile(self, *, user_id: int, skill: str):
        db = self._db()
        users = UserRepository(db)
        interns = InternRepository(db)

        u = users.get(user_id)
        if not u:
            raise ValidationError("userID invalid")
        if u.role != "Intern":
            raise ValidationError("userID must have role=Intern")
        if interns.get_by_user(user_id):
            raise ConflictError("InternProfile already exists for this user")

        try:
            return interns.create(user_id=user_id, skill=skill)
        except IntegrityError as ex:
            raise ConflictError(f"Cannot create intern profile: {ex.orig}")  # pragma: no cover

    def get_intern_profile(self, intern_id: int):
        db = self._db()
        interns = InternRepository(db)
        p = interns.get(intern_id)
        if not p:
            raise NotFoundError("InternProfile not found")
        return p

    def get_intern_by_user(self, user_id: int):
        db = self._db()
        interns = InternRepository(db)
        p = interns.get_by_user(user_id)
        if not p:
            raise NotFoundError("InternProfile not found")
        return p

    def update_intern_profile(self, intern_id: int, *, skill: Optional[str] = None):
        db = self._db()
        interns = InternRepository(db)
        p = interns.get(intern_id)
        if not p:
            raise NotFoundError("InternProfile not found")
        return interns.update(intern_id, skill=skill)

    def delete_intern_profile(self, intern_id: int):
        db = self._db()
        interns = InternRepository(db)
        p = interns.get(intern_id)
        if not p:
            raise NotFoundError("InternProfile not found")
        try:
            interns.delete(intern_id)
        except IntegrityError:
            # còn Assignment/Evaluation
            raise ConflictError("InternProfile is referenced (Assignment/Evaluation), cannot delete")
