# src/services/recruitment_service.py
from __future__ import annotations

from typing import Callable, Iterable, Optional
from sqlalchemy.exc import IntegrityError

from src.infrastructure.repositories.recruitment_repository import (
    CampaignRepository,
    ApplicationRepository,
)
from src.infrastructure.repositories.identity_repository import UserRepository
from src.domain.exceptions import ValidationError, ConflictError, NotFoundError


class RecruitmentService:
    """
    RecruitmentCampaign + Application
    """

    def __init__(self, db_provider: Callable):
        self._db = db_provider

    # --------- Campaign ---------

    def create_campaign(self, *, title: str, status: str = "Open"):
        db = self._db()
        repo = CampaignRepository(db)
        if status not in ("Open", "Closed"):
            raise ValidationError("status must be Open|Closed")
        return repo.create(title=title, status=status)

    def get_campaign(self, camp_id: int):
        db = self._db()
        repo = CampaignRepository(db)
        c = repo.get(camp_id)
        if not c:
            raise NotFoundError("Campaign not found")
        return c

    def list_campaigns(self, *, status: Optional[str] = None, limit: int = 50, offset: int = 0) -> Iterable:
        db = self._db()
        repo = CampaignRepository(db)
        return repo.list(status=status, limit=limit, offset=offset)

    def update_campaign(self, camp_id: int, *, title: Optional[str] = None, status: Optional[str] = None):
        db = self._db()
        repo = CampaignRepository(db)
        c = repo.get(camp_id)
        if not c:
            raise NotFoundError("Campaign not found")
        if status and status not in ("Open", "Closed"):
            raise ValidationError("status must be Open|Closed")
        return repo.update(camp_id, title=title, status=status)

    def delete_campaign(self, camp_id: int):
        db = self._db()
        repo = CampaignRepository(db)
        c = repo.get(camp_id)
        if not c:
            raise NotFoundError("Campaign not found")
        try:
            repo.delete(camp_id)
        except IntegrityError:
            raise ConflictError("Campaign has applications, cannot delete")

    def close_campaign(self, camp_id: int):
        db = self._db()
        repo = CampaignRepository(db)
        c = repo.get(camp_id)
        if not c:
            raise NotFoundError("Campaign not found")
        return repo.close(camp_id)

    # --------- Application ---------

    def apply(self, *, camp_id: int, user_id: int):
        db = self._db()
        camps = CampaignRepository(db)
        apps = ApplicationRepository(db)
        users = UserRepository(db)

        c = camps.get(camp_id)
        if not c:
            raise ValidationError("campID invalid")
        if c.status != "Open":
            raise ValidationError("Campaign is Closed")
        if not users.get(user_id):
            raise ValidationError("userID invalid")

        try:
            return apps.apply(camp_id=camp_id, user_id=user_id)
        except IntegrityError:
            # unique (campID, userID)
            raise ConflictError("Application already exists for this user and campaign")

    def get_application(self, app_id: int):
        db = self._db()
        apps = ApplicationRepository(db)
        a = apps.get(app_id)
        if not a:
            raise NotFoundError("Application not found")
        return a

    def list_applications(self, *, camp_id: Optional[int] = None, status: Optional[str] = None, limit: int = 50, offset: int = 0):
        db = self._db()
        apps = ApplicationRepository(db)
        return apps.list(camp_id=camp_id, status=status, limit=limit, offset=offset)

    def approve(self, app_id: int):
        db = self._db()
        apps = ApplicationRepository(db)
        a = apps.get(app_id)
        if not a:
            raise NotFoundError("Application not found")
        return apps.approve(app_id)

    def reject(self, app_id: int):
        db = self._db()
        apps = ApplicationRepository(db)
        a = apps.get(app_id)
        if not a:
            raise NotFoundError("Application not found")
        return apps.reject(app_id)

    def delete_application(self, app_id: int):
        db = self._db()
        apps = ApplicationRepository(db)
        a = apps.get(app_id)
        if not a:
            raise NotFoundError("Application not found")
        if a.status != "Pending":
            raise ConflictError("Only pending application can be deleted")
        apps.delete(app_id)
