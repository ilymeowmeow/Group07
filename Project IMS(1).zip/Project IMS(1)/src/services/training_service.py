# src/services/training_service.py
from __future__ import annotations

from typing import Callable, Iterable, Optional
from sqlalchemy.exc import IntegrityError

from src.infrastructure.repositories.training_repository import (
    ProgramRepository,
    ProjectRepository,
)
from src.domain.exceptions import ValidationError, ConflictError, NotFoundError


class TrainingService:
    """
    TrainingProgram + Project
    """

    def __init__(self, db_provider: Callable):
        self._db = db_provider

    # -------- Program --------

    def create_program(self, *, title: str, goal: str):
        db = self._db()
        repo = ProgramRepository(db)
        return repo.create(title=title, goal=goal)

    def get_program(self, prog_id: int):
        db = self._db()
        repo = ProgramRepository(db)
        p = repo.get(prog_id)
        if not p:
            raise NotFoundError("Program not found")
        return p

    def list_programs(self, limit: int = 50, offset: int = 0) -> Iterable:
        db = self._db()
        repo = ProgramRepository(db)
        return repo.list(limit=limit, offset=offset)

    def update_program(self, prog_id: int, *, title: Optional[str] = None, goal: Optional[str] = None):
        db = self._db()
        repo = ProgramRepository(db)
        p = repo.get(prog_id)
        if not p:
            raise NotFoundError("Program not found")
        return repo.update(prog_id, title=title, goal=goal)

    def delete_program(self, prog_id: int):
        db = self._db()
        repo = ProgramRepository(db)
        p = repo.get(prog_id)
        if not p:
            raise NotFoundError("Program not found")
        try:
            repo.delete(prog_id)
        except IntegrityError:
            raise ConflictError("Program still has projects, cannot delete")

    # -------- Project --------

    def create_project(self, *, prog_id: int, title: str):
        db = self._db()
        progs = ProgramRepository(db)
        projects = ProjectRepository(db)

        if not progs.get(prog_id):
            raise ValidationError("progID invalid")
        return projects.create(prog_id=prog_id, title=title)

    def get_project(self, proj_id: int):
        db = self._db()
        projects = ProjectRepository(db)
        p = projects.get(proj_id)
        if not p:
            raise NotFoundError("Project not found")
        return p

    def list_projects(self, *, prog_id: int, limit: int = 50, offset: int = 0) -> Iterable:
        db = self._db()
        projects = ProjectRepository(db)
        return projects.list_by_program(prog_id=prog_id, limit=limit, offset=offset)

    def delete_project(self, proj_id: int):
        db = self._db()
        projects = ProjectRepository(db)
        p = projects.get(proj_id)
        if not p:
            raise NotFoundError("Project not found")
        try:
            projects.delete(proj_id)
        except IntegrityError:
            raise ConflictError("Project has assignments, cannot delete")
