# src/services/work_service.py
from __future__ import annotations

from typing import Callable, Iterable
from sqlalchemy.exc import IntegrityError

from src.infrastructure.repositories.work_repository import AssignmentRepository
from src.infrastructure.repositories.training_repository import ProjectRepository
from src.infrastructure.repositories.identity_repository import InternRepository
from src.domain.exceptions import ValidationError, ConflictError, NotFoundError


_ALLOWED = {("Pending", "Doing"), ("Doing", "Done")}  # state machine


class WorkService:
    """
    Assignment (+ state transitions)
    """

    def __init__(self, db_provider: Callable):
        self._db = db_provider

    def create_assignment(self, *, proj_id: int, intern_id: int, status: str = "Pending"):
        db = self._db()
        projects = ProjectRepository(db)
        interns = InternRepository(db)
        assigns = AssignmentRepository(db)

        if not projects.get(proj_id):
            raise ValidationError("projID invalid")
        if not interns.get(intern_id):
            raise ValidationError("internID invalid")
        if status not in ("Pending", "Doing", "Done"):
            raise ValidationError("status must be Pending|Doing|Done")

        try:
            return assigns.create(proj_id=proj_id, intern_id=intern_id, status=status)
        except IntegrityError as ex:
            raise ConflictError(f"Cannot create assignment: {ex.orig}")  # pragma: no cover

    def get_assignment(self, assign_id: int):
        db = self._db()
        repo = AssignmentRepository(db)
        a = repo.get(assign_id)
        if not a:
            raise NotFoundError("Assignment not found")
        return a

    def list_by_project(self, proj_id: int, limit: int = 50, offset: int = 0) -> Iterable:
        db = self._db()
        repo = AssignmentRepository(db)
        return repo.list_by_project(proj_id, limit=limit, offset=offset)

    def list_by_intern(self, intern_id: int, limit: int = 50, offset: int = 0) -> Iterable:
        db = self._db()
        repo = AssignmentRepository(db)
        return repo.list_by_intern(intern_id, limit=limit, offset=offset)

    def update_status(self, assign_id: int, new_status: str):
        db = self._db()
        repo = AssignmentRepository(db)
        a = repo.get(assign_id)
        if not a:
            raise NotFoundError("Assignment not found")
        if (a.status, new_status) not in _ALLOWED:
            raise ValidationError("Invalid transition: only Pending→Doing or Doing→Done allowed")
        return repo.update_status(assign_id, new_status)

    def delete_assignment(self, assign_id: int):
        db = self._db()
        repo = AssignmentRepository(db)
        a = repo.get(assign_id)
        if not a:
            raise NotFoundError("Assignment not found")
        if a.status == "Done":
            raise ConflictError("Cannot delete when status=Done")
        repo.delete(assign_id)
